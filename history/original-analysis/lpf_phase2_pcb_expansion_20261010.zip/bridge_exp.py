import os,sys,time,json,itertools
import numpy as np
from scipy.optimize import minimize
from numba import njit
sys.path[:0]=['/mnt/data/lpf_next','/mnt/data/lpf_pcb_expansion']
from explore import COUPLES,three_series,SMALL,MED,DENSE,NAMES,psd
from expand import initial as old_initial
BASE=json.load(open('/mnt/data/lpf_phase2_extension/first.json'))
B,SER,CE=three_series(2)
@njit(cache=True)
def tr(L,k,Lp,C,f,pcbedges,cedges):
 out=np.empty(len(f),np.float64)
 for ix in range(len(f)):
  w=2*np.pi*f[ix]*1e6
  Z=np.zeros((4,4),np.complex128)
  for i in range(4):
   Z[i,i]=w*L[i]*1e-9*(1j+1/25.)
   if SER[i]: Z[i,i]+=(1/80.-1j)/(w*C[i]*1e-12)
  for i in range(6):
   a=COUPLES[i,0];b=COUPLES[i,1];Z[a,b]=Z[b,a]=1j*w*k[i]*np.sqrt(L[a]*L[b])*1e-9
  Y=B.T@np.linalg.solve(Z,B)
  for i in range(len(CE)):
   c=CE[i,0];a=CE[i,1];b=CE[i,2];y=w*C[c]*1e-12/(1/80.-1j)
   if a>=0:Y[a,a]+=y
   if b>=0:Y[b,b]+=y
   if a>=0 and b>=0:Y[a,b]-=y;Y[b,a]-=y
  for i in range(len(Lp)):
   a=pcbedges[i,0];b=pcbedges[i,1]
   c=C[4+i]
   zp=w*Lp[i]*1e-9*(1j+1/12.)+(1/80.-1j)/(w*c*1e-12)
   y=1/zp
   if a>=0:Y[a,a]+=y
   if b>=0:Y[b,b]+=y
   if a>=0 and b>=0:Y[a,b]-=y;Y[b,a]-=y
  for i in range(len(cedges)):
   a=cedges[i,0];b=cedges[i,1];y=w*C[4+len(Lp)+i]*1e-12/(1/80.-1j)
   if a>=0:Y[a,a]+=y
   if b>=0:Y[b,b]+=y
   if a>=0 and b>=0:Y[a,b]-=y;Y[b,a]-=y
  Y[0,0]+=1/50.;Y[3,3]+=1/(60-40j)
  rhs=np.zeros(4,np.complex128);rhs[0]=1/50.
  v=np.linalg.solve(Y,rhs)
  eta=4*50*(60/5200)*abs(v[3])**2
  out[ix]=-10*np.log10(max(eta,1e-100))
 return out

def optimize(pedges,cedges=(),init=None,tar=35.05,maxiter=180,grid=SMALL):
 ep=np.array(pedges,np.int64).reshape(-1,2);ec=np.array(cedges,np.int64).reshape(-1,2)
 nP=len(ep);nC=len(ec);D=4+nP+nC
 bnd=[(.4,27.)]*4+[(-.25,.25) if i in (2,3) else (-.16,.16) for i in range(6)]+[(.1,3.)]*nP+[(.1,100.)]*(6*D)
 base=np.array(BASE['x']); x0=np.r_[base[:10],np.full(nP,1.7),np.array([np.r_[base[10+4*b:14+4*b],np.full(nP,1.5),np.full(nC,.15)] for b in range(6)]).ravel()]
 if init is not None: x0=init
 x0=np.clip(x0,np.array(bnd)[:,0],np.array(bnd)[:,1]);z0=np.r_[x0,.6]
 def resp(x,b,f):return tr(x[:4],x[4:10],x[10:10+nP],x[10+nP+b*D:10+nP+(b+1)*D],f,ep,ec)
 def cons(z):
  x=z[:-1];t=z[-1];cc=[]
  for i,(p,s,h) in enumerate(grid):
   cc.extend(t-resp(x,i,p));cc.extend(resp(x,i,s)-tar);cc.extend(resp(x,i,h)-tar)
  cc.append(psd(x[4:10])-.01)
  return np.asarray(cc)
 tic=time.time()
 r=minimize(lambda z:z[-1],z0,method='SLSQP',constraints=[dict(type='ineq',fun=cons)],bounds=bnd+[(0,6)],options=dict(maxiter=maxiter,ftol=3e-9))
 x=r.x[:-1]
 vals=[(float(max(resp(x,b,p))),float(min(resp(x,b,s))),float(min(resp(x,b,t)))) for b,(p,s,t) in enumerate(DENSE)]
 m=(max(v[0] for v in vals),min(v[1] for v in vals),min(v[2] for v in vals))
 good=m[1]>=tar-.015 and m[2]>=tar-.015 and m[0]<r.x[-1]+.02 and psd(x[4:10])>.009
 return dict(pcb_edges=ep.tolist(),cap_edges=ec.tolist(),nP=nP,nC=nC,IL=m[0],H2=m[1],H3=m[2],good=bool(good),success=bool(r.success),Lpcb=x[10:10+nP].tolist(),x=x.tolist(),time=round(time.time()-tic,2),vals=dict(zip(NAMES,vals)),msg=r.message)

if __name__=='__main__':
 target='/mnt/data/lpf_pcb_expansion/bridge_results.json';out=[]
 patterns=[
  ([(1,-1),(0,2)],[]), ([(2,-1),(0,2)],[]), ([(1,-1),(1,3)],[]), ([(2,-1),(1,3)],[]),
  ([(0,2),(1,3)],[]), ([(0,3),(1,-1)],[]), ([(0,3),(2,-1)],[]),
  ([(1,-1),(2,-1)],[(0,2)]), ([(1,-1),(2,-1)],[(1,3)]), ([(1,-1),(2,-1)],[(0,3)]),
  ([(0,2),(1,-1)],[(2,-1)]), ([(1,3),(2,-1)],[(0,2)]),
  ([(0,-1),(1,-1),(2,-1)],[(0,2)]), ([(0,2),(1,-1),(2,-1)],[(1,3)]),
  ([(0,3),(1,-1),(2,-1)],[(0,2)]), ([(0,2),(1,3),(2,-1)],[(1,-1)]),
  ([(0,-1),(1,-1),(2,-1)],[(1,3),(0,2)]),
 ]
 # compile
 t=optimize(*patterns[0],maxiter=5);print('compiled',t['IL'],flush=True)
 for ep,ec in patterns:
  rr=optimize(ep,ec,maxiter=230)
  out.append(rr);json.dump(out,open(target,'w'),indent=1)
  print('BR',len(out),ep,ec,'IL',round(rr['IL'],6),'H2',round(rr['H2'],3),'H3',round(rr['H3'],3),'ok',rr['good'],'t',rr['time'],flush=True)
 best=sorted([r for r in out if r['good']],key=lambda d:d['IL'])
 for r in best[:4]:
  rr=optimize(r['pcb_edges'],r['cap_edges'],np.array(r['x']),maxiter=300,grid=MED)
  out.append(rr);json.dump(out,open(target,'w'),indent=1)
  print('POLISH',rr['pcb_edges'],rr['cap_edges'],'IL',round(rr['IL'],6),'H2',round(rr['H2'],3),'H3',round(rr['H3'],3),'ok',rr['good'],flush=True)
 print('BEST',[(round(r['IL'],5),r['pcb_edges'],r['cap_edges']) for r in sorted((r for r in out if r['good']),key=lambda d:d['IL'])[:8]],flush=True)
