import sys,json,numpy as np,csv
sys.path.insert(0,'/mnt/data/lpf_next')
from explore import *
ps=[('K025_35',next(d for d in json.load(open('/mnt/data/lpf_limit_study/limits.json')) if d['kmax']==.25 and d['target']==35.05)),('K050_35',next(d for d in json.load(open('/mnt/data/lpf_limit_study/limits.json')) if d['kmax']==.5 and d['target']==35.05)),('K025_33',next(d for d in json.load(open('/mnt/data/lpf_limit_study/target33.json')) if d['kmax']==.25)),('K050_33',next(d for d in json.load(open('/mnt/data/lpf_limit_study/target33.json')) if d['kmax']==.5))]

def single_power(x,f,ib):
 L=np.asarray(x[:4]); k=x[4:10]; C=np.asarray(x[10+4*ib:14+4*ib]);w=2*np.pi*f*1e6
 B,SC,E=three_series(2)
 Z=np.diag(w*L*1e-9*(1/25+1j)).astype('complex128')
 Zc=(1/80-1j)/(w*C*1e-12)
 Z[1,1]+=Zc[1]
 for ii,(a,b) in enumerate(COUPLES):Z[a,b]=Z[b,a]=1j*w*k[ii]*np.sqrt(L[a]*L[b])*1e-9
 Y=B.T@np.linalg.solve(Z,B)
 for j,a,b in E:
  yy=1/Zc[j];Y[a,a]+=yy;Y[b,b]+=yy;Y[a,b]-=yy;Y[b,a]-=yy
 Y[0,0]+=1/50;Y[3,3]+=1/(60-40j)
 v=np.linalg.solve(Y,np.array([1/50,0,0,0],complex))
 i=np.linalg.solve(Z,B@v)
 I=np.array([i[0],i[1],i[2],i[3]])
 # available input power for Vsrc = 1 V (RMS) equals 1/(4*50)=.005 W; normalization factor to 1W =200
 Lp=abs(i)**2*w*L*1e-9/25 *200
 Cp=np.zeros(4);Cp[1]=abs(i[1])**2*Zc[1].real*200
 for j,a,b in E: Cp[j]=abs(v[a]-v[b])**2*(1/Zc[j]).real*200
 refl=abs((1 - 2*v[0]))**2 # source reflection using source V=1; reflection wave current? gamma = 2 V_in-1 => same
 trans=4*50*(60/5200)*abs(v[3])**2
 assert abs((refl+trans+Lp.sum()+Cp.sum())-1)<1e-8, (refl,trans,Lp.sum(),Cp.sum())
 return dict(IL=-10*np.log10(trans), refl=refl, trans=trans,**{f'Lp{j+1}':float(p) for j,p in enumerate(Lp)},**{f'Cp{j+1}':float(p) for j,p in enumerate(Cp)},Psum=float(Lp.sum()+Cp.sum()), gamma=complex(2*v[0]-1))

rows=[]
for name,d in ps:
 print(name, 'IL',d['IL'], 'L',np.round(d['x'][:4],4), 'k',np.round(d['x'][4:10],4),'psd',d['PSD'])
 for bi,band in [(2,'B28'),(5,'B8')]:
  f=803 if bi==2 else 960
  s=single_power(d['x'],f,bi)
  row={'name':name,'band':band,'freq_MHz':f,**{a:(float(v) if not isinstance(v,complex) else abs(v)) for a,v in s.items()}}
  rows.append(row)
  print(band,'loss mW',np.round([s['Lp1'],s['Lp2'],s['Lp3'],s['Lp4']],4)*1e3,'C',sum(s[f'Cp{i}'] for i in range(1,5))*1000,'reflection',s['refl']*1000,'IL',s['IL'])
with open('/mnt/data/lpf_limit_study/power.csv','w',newline='') as fp:
 w=csv.DictWriter(fp,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
