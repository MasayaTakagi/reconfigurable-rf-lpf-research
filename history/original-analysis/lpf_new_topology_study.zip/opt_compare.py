import sys,json,time,itertools
import numpy as np
from numba import njit
from scipy.optimize import minimize
sys.path[:0]=['/mnt/data/lpf_sixband','/mnt/data/lpf_feasibility']
from lpf_sixband import BANDS,psd
from run_phase2 import NAMES,LARGE,SMALL
from lpf_sixband import il_four
records=json.load(open('/mnt/data/lpf_feasibility/pair_k_results.json'))
base4=next(r for r in records if r['id']=='4L4C' and r['pattern']=='pair_weak')
base3=next(r for r in records if r['id']=='3L3C' and r['pattern']=='pair_weak')

@njit(cache=True)
def il_new(x,ff,ql1=25.,qlsh=25.,qc=80.,extra_input=True):
 # x = [L1,L2,L3,L4,C1,C2,C3,C4,k12,k13,k23]
 L1,L2,L3,L4,C1,C2,C3,C4,k12,k13,k23=x
 y=np.empty(len(ff));Zload=60.-40.j
 for i in range(len(ff)):
  w=2.*np.pi*ff[i]*1e6
  z1=w*L1*1e-9*(1./ql1+1j)
  z2=w*L2*1e-9*(1./qlsh+1j)+(1./qc-1j)/(w*C2*1e-12)
  z3=w*L3*1e-9*(1./qlsh+1j)+(1./qc-1j)/(w*C3*1e-12)
  z4=w*L4*1e-9*(1./qlsh+1j)+(1./qc-1j)/(w*C4*1e-12)
  z12=1j*w*k12*np.sqrt(L1*L2)*1e-9
  z13=1j*w*k13*np.sqrt(L1*L3)*1e-9
  z23=1j*w*k23*np.sqrt(L2*L3)*1e-9
  d=z1*z2*z3+2*z12*z13*z23-z1*z23*z23-z2*z13*z13-z3*z12*z12
  g11=(z2*z3-z23*z23)/d
  g22=(z1*z3-z13*z13)/d
  g33=(z1*z2-z12*z12)/d
  g12=(z13*z23-z12*z3)/d
  g13=(z12*z23-z13*z2)/d
  g23=(z12*z13-z1*z23)/d
  yc=w*C1*1e-12/(1./qc-1j)
  y11=g11+g22+2*g12+yc
  y22=g11+g33-2*g13+yc
  y12=-g11+g13-g12+g23-yc
  if extra_input:y11+=1./z4
  else:y22+=1./z4
  vout=-(y12/50.)/((y11+1./50.)*(y22+1./Zload)-y12*y12)
  eta=4.*50.*(60./5200.)*abs(vout)**2
  y[i]=-10.*np.log10(max(eta,1e-160))
 return y

@njit(cache=True)
def il_new3(x,ff,ql1=25.,qlsh=25.,qc=80.):
 L1,L2,L3,C1,C2,C3,k12,k13,k23=x
 y=np.empty(len(ff));Zload=60.-40.j
 for i in range(len(ff)):
  w=2.*np.pi*ff[i]*1e6
  z1=w*L1*1e-9*(1./ql1+1j)
  z2=w*L2*1e-9*(1./qlsh+1j)+(1./qc-1j)/(w*C2*1e-12)
  z3=w*L3*1e-9*(1./qlsh+1j)+(1./qc-1j)/(w*C3*1e-12)
  z12=1j*w*k12*np.sqrt(L1*L2)*1e-9
  z13=1j*w*k13*np.sqrt(L1*L3)*1e-9
  z23=1j*w*k23*np.sqrt(L2*L3)*1e-9
  d=z1*z2*z3+2*z12*z13*z23-z1*z23*z23-z2*z13*z13-z3*z12*z12
  g11=(z2*z3-z23*z23)/d
  g22=(z1*z3-z13*z13)/d
  g33=(z1*z2-z12*z12)/d
  g12=(z13*z23-z12*z3)/d
  g13=(z12*z23-z13*z2)/d
  g23=(z12*z13-z1*z23)/d
  yc=w*C1*1e-12/(1./qc-1j)
  y11=g11+g22+2*g12+yc
  y22=g11+g33-2*g13+yc
  y12=-g11+g13-g12+g23-yc
  vout=-(y12/50.)/((y11+1./50.)*(y22+1./Zload)-y12*y12)
  eta=4.*50.*(60./5200.)*abs(vout)**2
  y[i]=-10.*np.log10(max(eta,1e-160))
 return y

def vector_to_x(z,i,nL):
 return np.r_[z[:nL],z[nL+3+nL*i:nL+3+nL*(i+1)],z[nL:nL+3]]

def eval_model(z,nL=4,ql1=25.,qlsh=25.,qc=80.,extra_input=True,dense=True):
 ffset=LARGE if dense else SMALL
 out=[]
 for i,name in enumerate(NAMES):
  x=vector_to_x(z,i,nL)
  f=(lambda freq:il_new(x,freq,ql1,qlsh,qc,extra_input)) if nL==4 else (lambda freq:il_new3(x,freq,ql1,qlsh,qc))
  p,b2,b3=[f(fff) for fff in ffset[i]]
  out.append((name,p,b2,b3))
 return out

def metrics(z,nL=4,ql1=25.,qlsh=25.,qc=80.,extra_input=True,dense=True):
 a=eval_model(z,nL,ql1,qlsh,qc,extra_input,dense)
 return dict(IL=float(max(max(p) for _,p,_,_ in a)),H2=float(min(min(b2) for _,_,b2,_ in a)),H3=float(min(min(b3) for _,_,_,b3 in a)),bands=[dict(band=n,IL=round(float(max(p)),5),H2=round(float(min(b2)),4),H3=round(float(min(b3)),4)) for n,p,b2,b3 in a])

def optim(seed,nL=4,ql1=25.,qlsh=25.,qc=80.,extra_input=True,atten=35.,cmin=.5,krange='two',fix_l1=None, maxiter=170):
 kbound={'weak':[(-.03,.03),(0,.25),(-.015,.015)],'two':[(-.25,.25),(-.25,.25),(-.02,.02)],'two_pos':[(0,.25),(0,.25),(-.02,.02)],'two_neg':[(-.25,0),(-.25,0),(-.02,.02)],'none':[(0,0)]*3}[krange]
 bs=([(fix_l1,fix_l1)] if fix_l1 is not None else [(1,27)])+[(1,27)]*(nL-1)+kbound+[(cmin,6)]*(6*nL)
 seed=np.clip(seed,np.array(bs)[:,0],np.array(bs)[:,1]);meta=metrics(seed,nL,ql1,qlsh,qc,extra_input)
 x0=np.r_[seed,max(meta['IL'],.45)+.15]
 def cons(z):
  ll=eval_model(z[:-1],nL,ql1,qlsh,qc,extra_input)
  vals=[]
  for _,p,h2,h3 in ll:
   vals.extend(z[-1]-p)
   vals.extend(h2-atten)
   vals.extend(h3-atten)
  vals.append(psd(z[nL:nL+3])-.005)
  return np.asarray(vals)
 t=time.monotonic()
 r=minimize(lambda z:z[-1],x0,method='SLSQP',bounds=bs+[(0,10)],constraints=[dict(type='ineq',fun=cons)],options=dict(maxiter=maxiter,ftol=5e-9))
 z=r.x[:-1];m=metrics(z,nL,ql1,qlsh,qc,extra_input);vi=float(min(cons(r.x)))
 d=dict(nL=nL,ql1=ql1,qlsh=qlsh,qc=qc,extra_input=extra_input,atten=atten,cmin=cmin,krange=krange,fix_l1=fix_l1,IL=m['IL'],H2=m['H2'],H3=m['H3'],bands=m['bands'],L=z[:nL].tolist(),k=z[nL:nL+3].tolist(),C=[z[nL+3+nL*i:nL+3+nL*(i+1)].tolist() for i in range(6)],valid=bool(vi>-1e-3 and m['H2']>atten-.001 and m['H3']>atten-.001), min_constraint=vi,nit=r.nit,sec=round(time.monotonic()-t,2),x=z.tolist())
 print('RESULT',nL,'QL1',ql1,'K',krange,'cmin',cmin,'layout',int(extra_input),'fix',fix_l1,'IL',round(d['IL'],5),'H2/3',round(d['H2'],3),round(d['H3'],3),'feas',d['valid'],'L1',round(d['L'][0],2),'k',np.round(d['k'],3),'time',d['sec'],flush=True)
 return d

if __name__=='__main__':
 seed4=np.asarray(base4['params']);seed3=np.asarray(base3['params'])
 out=[]
 def run(seed,nL=4,**kwargs):
  r=optim(np.array(seed),nL=nL,**kwargs);out.append(r)
  with open('/mnt/data/lpf_newwork/opt_results.json','w') as fp:json.dump(out,fp,indent=2)
  return np.asarray(r['x']) if r['valid'] else np.asarray(seed)
 # anchor results baseline
 a=run(seed4,krange='weak')
 # 2 strongly coupled adjacent to L1, including polarity differences
 b=run(a,krange='two');b=run(b,krange='two_pos');b=run(b,krange='two')
 c=run(a,krange='two_neg');c=run(c,krange='two')
 # avoid local minima try K perturbations guided
 for ka,kb in [(.2,.20),(.22,-.20),(-.20,.20),(-.2,-.2)]:
  s=a.copy();s[4]=ka;s[5]=kb
  run(s,krange='two',maxiter=130)
 # force smaller L1, reallocate matching to shunts
 for L1 in [7.,6.,5.,4.]:
  s=b.copy();s[0]=L1
  run(s,krange='two',fix_l1=L1,maxiter=140)
 # free from best low-L1 seed
 feasible=sorted([o for o in out if o['valid']],key=lambda o:o['IL'])
 best=np.array(feasible[0]['x'])
 run(best,krange='two',maxiter=200)
 # Q1 scenarios 
 for q in [30.,35.,48.]:
  run(best,krange='two',ql1=q,maxiter=180)
  run(a,krange='weak',ql1=q,maxiter=180)
 # secondary swapped extra trap position
 run(best,krange='two',extra_input=False,maxiter=180)
 # lower min C
 for cmin in [.35,.2]:
  run(best,krange='two',cmin=cmin,maxiter=180)
  run(best,krange='two',cmin=cmin,ql1=30.,maxiter=180)
 # 3L strong coupling and LQW option
 run(seed3,nL=3,krange='two',maxiter=160)
 run(seed3,nL=3,krange='two',ql1=30.,maxiter=160)
 print('BEST',min([o for o in out if o['valid']],key=lambda o:o['IL'])['IL'], 'DONE')
