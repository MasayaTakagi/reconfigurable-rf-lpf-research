import numpy as np, time, json
from scipy.optimize import differential_evolution, minimize

RS=50.0
ZLOAD=60-40j
F_PASS=np.linspace(600e6,960e6,181)
F_2=np.linspace(1760e6,1830e6,71)
F_3=np.linspace(2640e6,2745e6,106)
F=np.r_[F_PASS,F_2,F_3]
NP=len(F_PASS); N2=len(F_2)
W=2*np.pi*F

# Topologies: A: shunt C1, series L1, shunt C2, series L2, shunt C3
# B: series L1, shunt C1, shunt series-L3-C3, series L2, shunt C2
# C: series (L1||C1), series (L2||C2), shunt C3
# D: shunt series-L2-C2, series L1, shunt series-L3-C3, shunt C1
TYPES={
'A':('C1','L1','C2','L2','C3'),
'B':('L1','C1','L3','C3','L2','C2'),
'C':('L1','C1','L2','C2','C3'),
'D':('L1','L2','C1','L3','C2','C3'),
}

def calc_loss(x, typ, f=F):
    x=np.array(x, dtype=float)
    # x values in nH, pF sorted by the layout definitions
    if typ == 'A':
        c1,l1,c2,l2,c3=x
    elif typ=='B':
        l1,c1,l3,c3,l2,c2=x
    elif typ=='C':
        l1,c1,l2,c2,c3=x
    elif typ=='D':
        l1,l2,c1,l3,c2,c3=x
    w=2*np.pi*f
    def zl(L): return w*L*1e-9*(1/25+1j)
    def zc(C): return (1/80-1j)/(w*C*1e-12)
    a=np.ones_like(w,dtype=complex); b=np.zeros_like(w,dtype=complex)
    c=np.zeros_like(w,dtype=complex); d=np.ones_like(w,dtype=complex)
    def series(z):
        nonlocal a,b,c,d
        b=a*z+b
        d=c*z+d
    def shunt(y):
        nonlocal a,b,c,d
        a=a+b*y
        c=c+d*y
    if typ=='A':
        shunt(1/zc(c1)); series(zl(l1)); shunt(1/zc(c2)); series(zl(l2)); shunt(1/zc(c3))
    if typ=='B':
        series(zl(l1));shunt(1/zc(c1)+1/(zl(l3)+zc(c3)));series(zl(l2));shunt(1/zc(c2))
    if typ=='C':
        series(zl(l1)*zc(c1)/(zl(l1)+zc(c1)));series(zl(l2)*zc(c2)/(zl(l2)+zc(c2)));shunt(1/zc(c3))
    if typ=='D':
        shunt(1/(zl(l2)+zc(c2)));series(zl(l1));shunt(1/(zl(l3)+zc(c3))+1/zc(c1))
    den=a*ZLOAD+b+RS*(c*ZLOAD+d)
    eta=4*RS*ZLOAD.real/np.abs(den)**2
    return -10*np.log10(np.clip(eta,1e-200,1))

def bounds_for(t):
    return [(.05,27) if s.startswith('L') else (.05,100) for s in TYPES[t]]

def stats(x,t):
    l=calc_loss(x,t)
    p=l[:NP]; s2=l[NP:NP+N2];s3=l[NP+N2:]
    return dict(maxpass=float(p.max()),meanpass=float(p.mean()),minpass=float(p.min()),stop2=float(s2.min()),stop3=float(s3.min()),pass_max_freq=float(F_PASS[p.argmax()]/1e6),stop2_min_freq=float(F_2[s2.argmin()]/1e6),stop3_min_freq=float(F_3[s3.argmin()]/1e6))

def objective(x, typ, penalty=20):
    z=calc_loss(x,typ)
    p=z[:NP]
    d2=max(0,30-np.min(z[NP:NP+N2])); d3=max(0,30-np.min(z[NP+N2:]))
    return float(np.max(p)+penalty*(d2*d2+d3*d3))

if __name__=='__main__':
    results={}
    for j,typ in enumerate('ABCD'):
        tic=time.perf_counter()
        current=[]
        for seed in [42,123,999]:
            result=differential_evolution(objective,bounds_for(typ),args=(typ,25),strategy='best1bin',popsize=18,maxiter=500,atol=0.001,tol=0.001,polish=True,seed=seed,updating='immediate')
            current.append((result.fun,result.x,stats(result.x,typ)))
            print(typ, seed, 'obj',round(result.fun,5), 'values',np.round(result.x,4),'metrics',stats(result.x,typ),flush=True)
        best=min(current,key=lambda r:r[0])
        results[typ]=dict(obj=best[0],values=best[1].tolist(),stats=best[2],multiple=[dict(seed=ss,objective=float(a),values=b.tolist(),stats=c) for ss,(a,b,c) in zip([42,123,999],current)],elapsed=round(time.perf_counter()-tic,2))
        with open('/mnt/data/lpf_optimization.json','w') as fh:json.dump(results,fh,indent=2)
    print('FINISHED',json.dumps(results,indent=2))
