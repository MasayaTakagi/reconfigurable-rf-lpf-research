import json,time,numpy as np
from lpf_sixband import *
t0=time.time(); entries=[]
for band in ['B71','B8']:
 for coupled in [False,True]:
  x,m,dt=opt_single(band,coupled,'D+',iters=105,pop=8,seed=12 if coupled else 21)
  record=dict(phase='1',band=band,topology='D+',coupled=coupled,params=x.tolist(),metrics=m,run_sec=dt)
  entries.append(record)
  print(band, 'coupled',coupled,'IL',m['max_IL'],'minstops',m['stop2'],m['stop3'],'params',np.round(x,4),'time',dt,flush=True)
  open('/mnt/data/lpf_sixband/phase1.json','w').write(json.dumps(entries,indent=2))
print('all seconds',round(time.time()-t0,1))
