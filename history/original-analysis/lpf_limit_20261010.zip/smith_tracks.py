import json,sys,csv,numpy as np
sys.path.insert(0,'/mnt/data/lpf_next')
from explore import *
arr=json.load(open('/mnt/data/lpf_limit_study/limits.json'))
arr2=json.load(open('/mnt/data/lpf_limit_study/target33.json'))
sets=[('35dB_k025',next(x for x in arr if x['target']==35.05 and x['kmax']==.25)),('35dB_k050',next(x for x in arr if x['target']==35.05 and x['kmax']==.5)),('33dB_k025',next(x for x in arr2 if x['kmax']==.25)),('33dB_k050',next(x for x in arr2 if x['kmax']==.5))]
B,SC,E=three_series(2);rows=[]
for label,d in sets:
 x=np.array(d['x']);L=x[:4];k=x[4:10]
 for ib,f in [(2,803),(5,960)]:
  C=x[10+ib*4:14+ib*4];w=2*np.pi*f*1e6;Zc=(1/80-1j)/(w*C*1e-12)
  Z=np.diag(w*L*1e-9*(1/25+1j)).astype(complex);Z[1,1]+=Zc[1]
  for j,(a,b) in enumerate(COUPLES):Z[a,b]=Z[b,a]=1j*w*k[j]*np.sqrt(L[a]*L[b])*1e-9
  Y=B.T@np.linalg.solve(Z,B)
  for j,a,b in E:
   yy=1/Zc[j];Y[a,a]+=yy;Y[b,b]+=yy;Y[a,b]-=yy;Y[b,a]-=yy
  Y[0,0]+=1/50;Y[3,3]+=1/(60-40j)
  v=np.linalg.solve(Y,np.array([1/50,0,0,0],complex))
  I=np.linalg.solve(Z,B@v)
  I1=I[0]+(v[0]-v[1])/Zc[0]
  I4=I[3]+(v[1]-v[2])/Zc[3]
  I3=I[2]+(v[2]-v[3])/Zc[2]
  zin=np.array([60-40j,v[2]/I3,v[2]/I4,v[1]/I4,v[0]/I1]);g=(zin-50)/(zin+50)
  path=float(sum(abs(np.diff(g))))
  print(label,NAMES[ib],f,'IL',d['perband'][NAMES[ib]]['IL'],'Smith path',round(path,5),'|Gin|',abs(g[-1]))
  rows.append({'name':label,'band':NAMES[ib],'freq_MHz':f,'IL_dB':d['perband'][NAMES[ib]]['IL'],'smith_chords':path,'reflection':abs(g[-1])})
with open('/mnt/data/lpf_limit_study/smith_lengths.csv','w',newline='') as fp:
 w=csv.DictWriter(fp,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
