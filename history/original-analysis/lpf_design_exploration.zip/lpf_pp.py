import numpy as np,sys,json,itertools,time
from scipy.optimize import differential_evolution,minimize
from lpf_expand import SMALL,LARGE,DENSE,RS,ZD,K
# Two series parallel resonance blocks P2 P3, one series inductor L, one shunt capacitor C
# x = Lp2,f2,Lp3,f3,Ls,Cs
bounds=[(.15,27),(1.65,2.1),(.15,27),(2.4,3.1),(.005,27),(.01,100)]

def calc(x,ops,f=SMALL):
    l2,f2,l3,f3,ls,cs=x;w=2*np.pi*f
    zl=lambda L:w*L*1e-9*(.04+1j)
    zc=lambda C:(.0125-1j)/(w*C*1e-12)
    z2=zl(l2)*zc(K/(l2*f2*f2))/(zl(l2)+zc(K/(l2*f2*f2)))
    z3=zl(l3)*zc(K/(l3*f3*f3))/(zl(l3)+zc(K/(l3*f3*f3)))
    a=np.ones_like(w,dtype=complex);b=np.zeros_like(w,dtype=complex);c=np.zeros_like(w,dtype=complex);d=np.ones_like(w,dtype=complex)
    for op in ops:
        if op=='C':y=1/zc(cs);a=a+b*y;c=c+d*y
        else:
            z={'2':z2,'3':z3,'L':zl(ls)}[op]
            b=a*z+b;d=c*z+d
    den=a*ZD+b+RS*(c*ZD+d)
    return -10*np.log10(np.clip(4*RS*ZD.real/np.abs(den)**2,1e-100,1))
def met(x,ops,f=LARGE):
    r=calc(x,ops,f); n=(f<1e9).sum();m=((f>1e9)&(f<2e9)).sum()
    return [float(r[:n].max()),float(r[:n].mean()),float(r[n:n+m].min()),float(r[n+m:].min())]
def obj(x,ops,t):
    r=calc(x,ops);return float(r[:37].max()+50*(max(0,t-r[37:52].min())**2+max(0,t-r[52:].min())**2))
def sls(x,ops,t):
 def con(y):
    r=calc(y[:-1],ops,LARGE);return np.r_[y[-1]-r[:181],r[181:252]-t,r[252:]-t]
 return minimize(lambda y:y[-1],np.r_[x,met(x,ops)[0]+.03],bounds=bounds+[(0,25)],method='SLSQP',constraints={'type':'ineq','fun':con},options={'maxiter':200,'ftol':1e-9})
if __name__=='__main__':
 t=float(sys.argv[1]) if len(sys.argv)>1 else 30.05
 out=[]
 for op in itertools.permutations('23LC'):
  st=time.perf_counter(); candidates=[]
  for sd in [12,41]:
   de=differential_evolution(obj,bounds,args=(op,t),seed=sd,maxiter=190,popsize=10,polish=True,atol=.0003,tol=.002)
   res=sls(de.x,op,t)
   x=res.x[:-1] if res.success and min(met(res.x[:-1],op)[2:])>t-1e-4 else de.x
   mm=met(x,op)
   if min(mm[2:])>t-1e-4:candidates.append((mm[0],x))
  if candidates:
   _,x=min(candidates,key=lambda a:a[0]);mm=met(x,op,DENSE)
   out.append(dict(name=''.join(op),values=x.tolist(),metrics=mm))
   print('PP', ''.join(op),'IL',round(mm[0],5),'s2/3',np.round(mm[2:],4),'x',np.round(x,4),'sec',round(time.perf_counter()-st,1),flush=True)
  else:print('PP', ''.join(op),'NO FEAS',round(time.perf_counter()-st,1),flush=True)
  with open('/mnt/data/pp_'+str(t)+'.json','w') as fw:json.dump(out,fw,indent=2)
