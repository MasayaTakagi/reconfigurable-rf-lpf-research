# LPF 6-case low-loss topology revision (2026-10-10)

## Scope
Cases: B71, B12, B28, B13+B14 (one setting), B26, B8.
Passbands: UL and DL. Stopbands: twice and three times each UL span. Source 50 ohm, load 60-40j ohm.

## Linear circuit model
Coupled inductor L1 as series branch between source input and interior node, L2-C2 series shunt at input, L3-C3 series shunt at output. C1 is in parallel with L1. L4 and C4 are parallel to each other, in series with the signal path between interior node and output. Mutual couplings k12,k13,k23 are between L1, L2, L3. L4 uncoupled. Constant-Q impedance model with Q_L1 and Q_L4 25 or 30; Q_L2=Q_L3=25; Q_C=80. No chip/package/parasitic/SRF/nonlinear/switch models.

## Findings
* Old D+ plus extra input shunt trap: worst pass IL 0.439 dB for QL=25 and nominal >=35 dB stop attenuation.
* New topology (two series parallel-LC tanks plus input/output series-LC shunts): worst pass IL 0.4059 dB (QL1=QL4=25), 0.3728 dB (QL1=30, QL4=25), 0.3522 dB (QL1=QL4=30). Each new candidate optimized with 35.05-dB stop requirement and validated on a 0.1 MHz dense sweep.
* Main coupling k13 is about 0.10~0.18 with almost zero k12, k23. Granting two simultaneously strong couplings in old topology did not improve that topology in local optimization.
* Finite-Q and 0.5pF minimum capacity are assumptions; not validated against physical Murata parts. LQW04 actual Q(f), SRF and coupling differ across values.

## Files
* `opt_compare.py`: numerical small-signal optimization for old topology and Q comparisons.
* `alt_topology.py`: independently implemented 3-node MNA solver with two series LC parallel tanks.
* `refined_results.json`: 6-band designs, L/C/k, candidate losses and margins at 35.05 dB target.
* `loss_decomp.py` and `loss_breakdown.csv`: branch-current and dissipated-power validation (1 W source-available-power normalization, not an asserted PA spec).
* `finalize.py`: optimization refinement and 0.1 MHz dense sweep.

## Limits
SLSQP yields local feasible solutions, not proof of global optimum. A 0.1-MHz grid is dense numerical verification, not a continuous-frequency interval proof. The B13 and B14 bands share a single capacitor state. Phase 3 switched-capacitor design is NOT performed.
