import json,sys,time, numpy as np
from numba import njit
from scipy.optimize import minimize
sys.path[:0]=['/mnt/data/lpf_sixband','/mnt/data/lpf_feasibility','/mnt/data/lpf_newwork']
from run_phase2 import NAMES,LARGE
from lpf_sixband import psd
from opt_compare import base4,metrics,optim

@njit(cache=True)
def IL_3node(x,ff,topo=0,QL1=25., QL4=25., QLsh=25., QC=80.):
 # L1 L2 L3 L4 C1 C2 C3 C4 and couplings k12 k13 k23
 L1,L2,L3,L4,C1,C2,C3,C4,k12,k13,k23=x
 out=np.empty(len(ff))
 for i in range(len(ff)):
  w=2*np.pi*ff[i]*1e6
  z1=(1/QL1+1j)*w*L1*1e-9
  z2=(1/QLsh+1j)*w*L2*1e-9+(1/QC-1j)/(w*C2*1e-12)
  z3=(1/QLsh+1j)*w*L3*1e-9+(1/QC-1j)/(w*C3*1e-12)
  z4=(1/QL4+1j)*w*L4*1e-9
  z12=1j*w*k12*np.sqrt(L1*L2)*1e-9
  z13=1j*w*k13*np.sqrt(L1*L3)*1e-9
  z23=1j*w*k23*np.sqrt(L2*L3)*1e-9
  z=np.array([[z1,z12,z13],[z12,z2,z23],[z13,z23,z3]])
  # nodal branch incidence for L1 0-1; L2 input-ground; L3 output-ground
  B=np.array([[1.+0j,-1.+0j,0j],[1.+0j,0j,0j],[0j,0j,1.+0j]])
  # 3 node admittance
  yn=B.T@np.linalg.solve(z,B)
  yc1=1/((1/QC-1j)/(w*C1*1e-12))
  yn[0,0]+=yc1;yn[1,1]+=yc1;yn[0,1]-=yc1;yn[1,0]-=yc1
  # L4 between middle and output, either parallel C4 (type0), C4 shunt internal (type1), series C4 with L4 (type2)
  if topo==0: y4=1/z4+1/((1/QC-1j)/(w*C4*1e-12))
  elif topo==1:y4=1/z4
  else:y4=1/(z4+(1/QC-1j)/(w*C4*1e-12))
  yn[1,1]+=y4;yn[2,2]+=y4;yn[1,2]-=y4;yn[2,1]-=y4
  if topo==1:yn[1,1]+=1/((1/QC-1j)/(w*C4*1e-12))
  yn[0,0]+=1/50.
  yn[2,2]+=1/(60-40j)
  volt=np.linalg.solve(yn,np.array([1/50.,0j,0j]))
  eta=4*50*(60/5200)*abs(volt[2])**2
  out[i]=-10*np.log10(max(eta,1e-160))
 return out

def xpar(z,i):return np.r_[z[:4],z[7+4*i:11+4*i],z[4:7]]
def ev(z,topo,QL1=25.,QL4=25.,dense=True):
 out=[]
 for i,name in enumerate(NAMES):
  x=xpar(z,i)
  sets=LARGE[i]
  p,h2,h3=[IL_3node(x,ff,topo,QL1,QL4) for ff in sets]
  out.append((name,p,h2,h3))
 return out

def opt(z0,topo,ql1=25.,ql4=25.,atten=35,cmin=.5,kbounds=None,maxiter=200):
 if kbounds is None:kbounds=[(-.25,.25),(-.25,.25),(-.03,.03)]
 bd=[(1,27)]*4+kbounds+[(cmin,6)]*24
 z0=np.clip(z0,np.array(bd)[:,0],np.array(bd)[:,1]); x0=np.r_[z0,1.5]
 def con(xx):
  vv=ev(xx[:-1],topo,ql1,ql4)
  arr=[]
  for _,p,h2,h3 in vv:
   arr.extend(xx[-1]-p);arr.extend(h2-atten);arr.extend(h3-atten)
  arr.append(psd(xx[4:7])-.005)
  return np.asarray(arr)
 t=time.time()
 r=minimize(lambda xx:xx[-1],x0,method='SLSQP',bounds=bd+[(0,10)],constraints=[dict(type='ineq',fun=con)],options=dict(maxiter=maxiter,ftol=1e-8))
 vv=ev(r.x[:-1],topo,ql1,ql4)
 IL=max(float(max(p)) for _,p,_,_ in vv)
 H2=min(float(min(h2)) for _,_,h2,_ in vv)
 H3=min(float(min(h3)) for _,_,_,h3 in vv)
 good=bool(min(con(r.x))>-.003 and H2>atten-.003 and H3>atten-.003)
 ret=dict(topo=topo,ql1=ql1,ql4=ql4,IL=IL,H2=H2,H3=H3,good=good,L=r.x[:4].tolist(),k=r.x[4:7].tolist(),C=[r.x[7+4*i:11+4*i].tolist() for i in range(6)],x=r.x[:-1].tolist(),seconds=round(time.time()-t,1),nit=r.nit,bands=[dict(band=n,IL=float(max(p)),H2=float(min(h2)),H3=float(min(h3))) for n,p,h2,h3 in vv])
 print('ALT',topo,ql1,ql4,'IL',round(IL,4),'H2',round(H2,3),'H3',round(H3,3),'good',good,'L',np.round(ret['L'],2),'K',np.round(ret['k'],2),'time',ret['seconds'],flush=True)
 return ret

if __name__=='__main__':
 seed=np.array(base4['params']);out=[]
 def run(z,topo,**kw):
  r=opt(z,topo,**kw);out.append(r)
  json.dump(out,open('/mnt/data/lpf_newwork/alt_results.json','w'),indent=2)
  return np.array(r['x']) if r['good'] else z
 for topo in range(3):
  z=seed.copy()
  z=run(z,topo)
  for m in [0.6,1.5]:
   s=z.copy();s[3]=8*m
   run(s,topo,maxiter=170)
  # high q L1, L4
  run(z,topo,ql1=30.,ql4=30.,maxiter=130)
