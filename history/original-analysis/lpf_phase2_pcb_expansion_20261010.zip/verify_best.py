import sys,json,csv,os
import numpy as np
sys.path[:0]=['/mnt/data/lpf_next','/mnt/data/lpf_pcb_expansion']
from explore import BANDS,NAMES,COUPLES,three_series
from coupled_extraC import tr
from coupled_pcb import psd
root='/mnt/data/lpf_pcb_expansion'
d=json.load(open(root+'/coupled_extraC_results.json'));best=sorted((r for r in d if r['feasible']),key=lambda r:r['IL'])[0]
x=np.array(best['x']);nP=3;nC=len(best['edges']);D=4+nP+nC
B4,ser,CE=three_series(2)
B=np.zeros((7,4),np.complex128);B[:4]=B4;B[4:,1]=1
chip=np.array([1,2,3],dtype=np.int64);eds=np.array(best['edges'],np.int64)
L=x[:4];k=x[4:10];LP=x[10:13];kp=x[13:16]
def response(bname,mult=1,xpert=None,step=.02):
 d=BANDS[bname];ranges=(d['ul']+d['dl']) if mult==1 else d['ul']
 ff=np.unique(np.concatenate([np.linspace(a*mult,b*mult,round((b-a)*mult/step)+1) for a,b in ranges]))
 xx=x if xpert is None else xpert
 i=NAMES.index(bname);C=xx[16+i*D:16+(i+1)*D]
 yy=tr(xx[:4],xx[4:10],xx[10:13],xx[13:16],C,ff,B,chip,eds)
 return (float(np.max(yy)) if mult==1 else float(np.min(yy))),float(ff[np.argmax(yy) if mult==1 else np.argmin(yy)])
def summary(y):
 vals=[(name,*response(name,1,y),*response(name,2,y),*response(name,3,y)) for name in NAMES]
 return max(row[1] for row in vals), min(row[3] for row in vals), min(row[5] for row in vals),vals
v=summary(x)
print('BASE',v[:3],'PSD',psd(k,kp,chip),'Lchip',L,'Lpcb',LP,'kchip',k,'kpcb',kp)
with open(root+'/verified_best_per_band.csv','w',newline='') as f:
 w=csv.writer(f);w.writerow(['case','max_pass_IL_dB','IL_at_MHz','min_H2_dB','H2_at_MHz','min_H3_dB','H3_at_MHz']);w.writerows(v[3])
with open(root+'/verified_best_Cs.csv','w',newline='') as f:
 w=csv.writer(f);w.writerow(['case','C1_pF','C2_pF','C3_pF','C4_pF','C5_PCB_pF','C6_PCB_pF','C7_PCB_pF','C8_bridge_pF'])
 for i,name in enumerate(NAMES):w.writerow([name]+np.round(x[16+i*D:16+(i+1)*D],6).tolist())
# Couple ±0.01 perturb same sign across PCB-chip k and one-at-a-time
rows=[]
for idx in range(3):
 for dv in [-.02,-.01,.01,.02]:
  y=x.copy();y[13+idx]+=dv
  il,h2,h3,_=summary(y)
  rows.append([f'kpcb{idx+1}',dv,il,h2,h3])
for dv in [-.02,-.01,.01,.02]:
 y=x.copy();y[13:16]+=dv
 il,h2,h3,_=summary(y)
 rows.append(['all_kpcb',dv,il,h2,h3])
for step in [-.01,.01]:
 y=x.copy();y[16:]*=(1+step)
 il,h2,h3,_=summary(y)
 rows.append(['all_C_relative',step,il,h2,h3])
with open(root+'/best_sensitivity.csv','w',newline='') as f:
 w=csv.writer(f);w.writerow(['perturbation','delta','max_IL_dB','min_H2_dB','min_H3_dB']);w.writerows(rows)
for r in rows: print('SEN',r)
