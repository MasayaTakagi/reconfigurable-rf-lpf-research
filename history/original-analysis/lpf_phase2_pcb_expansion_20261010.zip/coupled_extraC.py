import sys,os,json,time,numpy as np
from scipy.optimize import minimize
from numba import njit
sys.path[:0]=['/mnt/data/lpf_next','/mnt/data/lpf_pcb_expansion']
from explore import SMALL,MED,DENSE,NAMES,COUPLES,three_series
from coupled_pcb import psd
B4,SER4,CE=three_series(2)
best=min((r for r in json.load(open('/mnt/data/lpf_pcb_expansion/coupled_three_results.json')) if r['feasible'] and r['nodes']==[1,1,1] and r['chipids']==[1,2,3]),key=lambda r:r['IL'])
@njit(cache=True)
def tr(L,k,Lp,kp,C,fs,B,chipids,edges):
 npcb=len(Lp); nN=B.shape[1];out=np.empty(len(fs),np.float64)
 for it in range(len(fs)):
  w=2*np.pi*fs[it]*1e6
  z=np.zeros((4+npcb,4+npcb),np.complex128)
  for i in range(4):
   z[i,i]=w*L[i]*1e-9*(1j+1/25.)
   if SER4[i]: z[i,i]+=(1/80.-1j)/(w*C[i]*1e-12)
  for i in range(npcb):
   z[4+i,4+i]=w*Lp[i]*1e-9*(1j+1/12.)+(1/80.-1j)/(w*C[4+i]*1e-12)
   a=chipids[i];val=1j*w*kp[i]*np.sqrt(L[a]*Lp[i])*1e-9
   z[a,4+i]=val;z[4+i,a]=val
  for i in range(6):
   a=COUPLES[i,0];b=COUPLES[i,1];val=1j*w*k[i]*np.sqrt(L[a]*L[b])*1e-9
   z[a,b]=val;z[b,a]=val
  Y=B.T@np.linalg.solve(z,B)
  for j in range(len(CE)):
   a=CE[j,1];b=CE[j,2];val=w*C[CE[j,0]]*1e-12/(1/80.-1j)
   if a>=0:Y[a,a]+=val
   if b>=0:Y[b,b]+=val
   if a>=0 and b>=0:Y[a,b]-=val;Y[b,a]-=val
  for i in range(len(edges)):
   a=edges[i,0];b=edges[i,1];val=w*C[4+npcb+i]*1e-12/(1/80.-1j)
   if a>=0:Y[a,a]+=val
   if b>=0:Y[b,b]+=val
   if a>=0 and b>=0:Y[a,b]-=val;Y[b,a]-=val
  Y[0,0]+=1/50.;Y[3,3]+=1/(60-40j)
  rhs=np.zeros(nN,np.complex128);rhs[0]=1/50.
  v=np.linalg.solve(Y,rhs)
  eta=4*50*(60/5200)*abs(v[-1])**2
  out[it]=-10*np.log10(max(eta,1e-99))
 return out

def fit(edges,maxiter=200,stage=SMALL,init=None):
 nodes=[1,1,1];cp=[1,2,3]; nP=3;nC=len(edges);D=4+nP+nC
 B=np.zeros((4+nP,4),np.complex128);B[:4]=B4
 for j in range(nP):B[4+j,nodes[j]]=1
 edges=np.asarray(edges,dtype=np.int64).reshape(-1,2);chip=np.asarray(cp,dtype=np.int64)
 bounds=[(.4,27)]*4+[(-.25,.25) if i in [2,3] else (-.16,.16) for i in range(6)]+[(.1,3)]*nP+[(-.16,.16)]*nP+[(.1,100)]*(6*D)
 x0=np.asarray(best['x'])
 if init is None: x=np.r_[x0[:16],np.array([np.r_[x0[16+j*7:16+(j+1)*7],np.full(nC,.15)] for j in range(6)]).ravel()]
 else:x=init.copy()
 z=np.r_[x,.7]
 def freq(x,j,f):return tr(x[:4],x[4:10],x[10:13],x[13:16],x[16+j*D:16+(j+1)*D],f,B,chip,edges)
 def con(z):
  x=z[:-1];t=z[-1];res=[]
  for j,(p,s,h) in enumerate(stage):res.extend(t-freq(x,j,p));res.extend(freq(x,j,s)-35.05);res.extend(freq(x,j,h)-35.05)
  res.append(psd(x[4:10],x[13:16],cp)-.01)
  return np.array(res)
 time0=time.time();rr=minimize(lambda z:z[-1],z,bounds=bounds+[(0,6)],method='SLSQP',constraints=[dict(type='ineq',fun=con)],options={'maxiter':maxiter,'ftol':3e-9})
 x=rr.x[:-1];vals=[(float(max(freq(x,j,p))),float(min(freq(x,j,s))),float(min(freq(x,j,h)))) for j,(p,s,h) in enumerate(DENSE)]
 il=max(v[0] for v in vals);h2=min(v[1] for v in vals);h3=min(v[2] for v in vals)
 return {'edges':edges.tolist(),'IL':il,'H2':h2,'H3':h3,'feasible':bool(h2>=35.035 and h3>=35.035 and il<rr.x[-1]+.02 and psd(x[4:10],x[13:16],cp)>.009),'x':x.tolist(),'time':round(time.time()-time0,2),'Cextra':x[23::D].tolist(),'perband':dict(zip(NAMES,vals))}

if __name__=='__main__':
 patterns=[[(0,2)],[(1,-1)],[(2,-1)],[(0,3)],[(1,3)],[(0,2),(1,-1)],[(1,-1),(2,-1)],[(0,2),(2,-1)],[(0,2),(1,-1),(2,-1)]]
 out=[];name='/mnt/data/lpf_pcb_expansion/coupled_extraC_results.json'
 for ce in patterns:
  r=fit(ce, maxiter=220)
  out.append(r);json.dump(out,open(name,'w'),indent=1)
  print('CEC',ce,'IL',round(r['IL'],6),'H2',round(r['H2'],3),'H3',round(r['H3'],3),'ok',r['feasible'],'extraC',np.round(r['Cextra'],3),'t',r['time'],flush=True)
 for r in sorted((r for r in out if r['feasible']),key=lambda x:x['IL'])[:2]:
  rr=fit(r['edges'],init=np.array(r['x']),maxiter=300,stage=MED)
  out.append(rr);json.dump(out,open(name,'w'),indent=1)
  print('REFINE',rr['edges'],'IL',round(rr['IL'],6),'H2',round(rr['H2'],3),'H3',round(rr['H3'],3),'ok',rr['feasible'],flush=True)
