# Six-case LTE tunable notch LPF — Phase 1/2 numerical exploration

Date: 2026-10-10 (JST)

## Cases and definitions

| Case | UL MHz | DL MHz |
|---|---|---|
| B71 | 663-698 | 617-652 |
| B12 | 699-716 | 729-746 |
| B28 | 703-748 | 758-803 |
| B13+14 | 777-787,788-798 | 746-756,758-768 |
| B26 | 814-849 | 859-894 |
| B8 | 880-915 | 925-960 |

- Passbands are the **union** of that case's UL and DL intervals.
- Stopbands are exactly the **2x and 3x** frequency intervals of each case's UL.
- B13+14 is *one switch state* covering both bands (not one state per band).
- Rs = 50 ohms, Zload = 60 - j40 ohms for all frequencies.
- Loss is transducer insertion loss relative to available source power, including load mismatch.
- Nominal rejection >=30 dB for both stopbands.
- Initial model uses series R_L = omega*L/25 and series ESR_C = abs(X_C)/80.
- Capacitors are continuously adjustable in Phase 1/2, **not switched-bank hardware yet**.

## Topologies evaluated

1. D: input series LC shunt, series L, output series LC shunt (3L2C).
2. D+: same with parallel C across the series L (3L3C).
3. Coupled D+: magnetic mutuals between all three inductors (3L3C).
4. Added input LC trap: D+ plus one more shunt series-LC at input (4L4C, mutuals only among original 3 coils).
5. Added output LC trap: D+ plus one more shunt series-LC at output (4L4C, investigated but not selected).
6. Reversed D+ trap naming (tested, electrically isomorphic under complete relabeling).

The 4L4C model has L1 || C1 in the series path; shunt at input L2+C2 and L4+C4; shunt at output L3+C3. L4 is **not** coupled to L1/L2/L3 in this search.

L values in nH, C in pF. Shared fixed inductances and couplings across the six cases, but capacitors vary by case. The search was local and multistart, with continuous C, bounds 1-27 nH, >=0.15 pF for initial nominal candidates, |k|<=0.45, PSD coupling matrix. The screening case tightened to C>=0.5 pF and |k|<=0.25; these constraints are assumptions, not real component ratings.

## Representative candidates, 0.1 MHz validation

| Topology | Worst passband IL, dB | Global min H2, dB | Global min H3, dB |
|---|---:|---:|---:|
| D_3L2C | 0.606866 | 30.000100 | 30.000100 |
| Dplus_uncoupled_3L3C | 0.470653 | 30.000100 | 30.000100 |
| Dplus_coupled_3L3C | 0.438005 | 30.000200 | 29.999932 |
| 4L4C_ideal30 | 0.328162 | 30.000200 | 30.000200 |
| 4L4C_screen30 | 0.395547 | 30.000200 | 30.000200 |
| 4L4C_screen35 | 0.438854 | 35.000000 | 35.000000 |

**Important:** For Dplus_coupled_3L3C one 0.1 MHz validation point gives H3 just below 30.000 dB by less than 0.0001 dB; that near-boundary candidate does **not** strictly pass 30 dB without rounding or retuning. Other candidates must also be checked with true interval extrema, not merely a finite frequency grid.

## Phase 1 completed (single-band individual L/C/k)

- B71 D+ no coupling: ~0.398 dB maximum IL; coupled: ~0.342 dB.
- B8 D+ no coupling: ~0.397 dB maximum IL; coupled: ~0.341 dB.
- These are different optimized fixed-L values, so they cannot be naively used as a six-state common board.

## Phase 2 completed (selected topology family search)

- Six-state common circuit, all-band minimax IL with 30 dB nominal rejection.
- Uncoupled D+: ~0.471 dB.
- Coupled D+: ~0.438 dB (needs ~0.0001 dB retuning for 0.1 MHz strict pass).
- 4L4C input-trap extension: ~0.328 dB optimistic continuous-C model.
- 4L4C screening with C>=0.5 pF, |k|<=0.25: ~0.396 dB at 30 dB target.
- Same screened 4L4C, 35 dB nominal target: ~0.439 dB.

These are **numerically found feasible candidates** on dense grids, not global minima, not guaranteed against tolerances.

## 4L4C screened 35 dB preferred design

Fixed components and coupling:
- L1 = 8.6803885 nH
- L2 = 18.4683606 nH
- L3 = 11.3580252 nH
- L4 = 7.5693125 nH
- k12 = 0.0363388
- k13 = 0.1357444
- k23 = -0.0016415

Band-specific ideal C setting (pF):

| Case | C1 | C2 | C3 | C4 |
|---|---:|---:|---:|---:|
| B71 | 1.05103 | 0.84582 | 0.71671 | 0.77549 |
| B12 | 1.36687 | 0.57211 | 0.58526 | 0.71201 |
| B28 | 0.96345 | 0.76011 | 0.60500 | 0.70237 |
| B13+14 | 0.72508 | 0.62274 | 0.62974 | 0.61144 |
| B26 | 0.65417 | 0.56931 | 0.51338 | 0.51958 |
| B8 | 0.50000 | 0.50000 | 0.50000 | 0.50000 |

## Roadmap, subsequent phases

- **Phase 3 — Switched-cap architecture:** identify actual RF switch/stack topology and capacitor technology, control codebook; optimize 3/4/5-bit banks including ON R, OFF C, nonlinear capacitance and bond/wiring parasitics. Pass when all six cases meet nominal 35 dB on realistic component models and the agreed IL target; determine switching settling/overshoot.
- **Phase 4 — Multi-band robust co-optimization:** jointly optimize topology/part selection, shared L, feasible k, and per-band integer switch codes; include Monte Carlo tolerances plus worst-case corners; ensure >=30 dB in specified PVT corners with margin, and bound continuous-frequency extrema.
- **Phase 5 — High power (>23 dBm):** user must set exact Pmax (e.g. 27/30/33 dBm), modulation and worst load VSWR. HB/PA co-simulation, voltage stress across series-cap banks including OFF branches, power loss/thermal, P1dB, IMD, EVM and ACLR as appropriate; check power-generated H2/H3 rather than only passive transducer IL.
- **Phase 6 — EM + parts:** layout coil relative orientation to realize K, self-resonances for high-L coils, RF switching isolation, ESD, ground return; EM-circuit co-optimization and PCB prototype.
- **Phase 7 — Test + bounded optimality:** characterize 6 settings UL and DL S-parameters, harmonic load pull under high power, temp/voltage/switch codes and PVT; enumerate bounded schematic/topology family, formal interval verification + validated global optimization when feasible.

## Constraints and status

- This **does not prove** global optimality across all L/C graphs. No bridge topologies or all 4-coil mutual combinations were exhaustively searched.
- k constraints were imposed by model but not validated against a specific physical coil placement. Eigenpositive inductance matrix is necessary but not sufficient for geometric realizability.
- Q_L=25 and Q_C=80 were held constant through 2.7 GHz. Actual 27 nH coils may have SRF below some harmonic frequencies; thus model improvement may not be realizable.
- Continuous ideal capacitor values are NOT realizable discrete switch-bank codes until Phase 3.
- Dense frequency sampling at 0.1 MHz is still not a mathematical proof of entire-band satisfaction.
- For 35 dB design, 5 dB is nominal model headroom only, NOT a demonstrated post-tolerance margin.

## How to reproduce

Run `python lpf_sixband.py test`. Run `run_phase1.py`, `run_phase2.py`, `refine_joint.py`, `run_4L.py`, `continue_4L.py`, `realism.py`, and `margin4.py` to replicate the search flow. Re-run `build_report.py` for summary CSV and plots. Requires numpy, scipy, numba, matplotlib. Differential evolution is seed sensitive; these numerical candidates are saved in the JSON files. Some experiments are stochastic/multistart and may not recover exactly identical outcomes.

The band data is from 3GPP TS 36.101 Table 5.5-1: https://itecspec.com/3gpp/36.101/s/5.5
