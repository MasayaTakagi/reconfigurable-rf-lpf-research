import sys, os, json, time
import numpy as np
from scipy.optimize import minimize
sys.path.insert(0,'/mnt/data/lpf_next')
from explore import *
OUT='/mnt/data/lpf_limit_study'
Q=np.array([25.,25.,25.,25.,80.]); T=three_series(2)
pre=json.load(open('/mnt/data/lpf_next/target.json'))
relax=json.load(open('/mnt/data/lpf_next/relax.json'))
tight=json.load(open('/mnt/data/lpf_next/tight.json'))
mi=json.load(open('/mnt/data/lpf_next/min30.json'))
front=json.load(open('/mnt/data/lpf_next/frontier.json'))
seeds={'base35':np.array(next(d['x'] for d in pre if d.get('label')=='allpolish35')),
 'base34':np.array(next(d['x'] for d in pre if d.get('label')=='allpolish34')),
 'base30':np.array(mi[0]['x']),
 'relax35':np.array(next(d['x'] for d in relax if d.get('label')=='k03535'))}

def tune(v0,tar,kmax,stage=MED,maxiter=350, cmin=.1,Lmin=.4, Lmax=27, otherlimit=None):
 kb=[(-kmax,kmax)]*6 if otherlimit is None else [(-otherlimit if isinstance(otherlimit,(int,float)) else -otherlimit[0],otherlimit if isinstance(otherlimit,(int,float)) else otherlimit[0])]*6
 if otherlimit is not None:
  pair_ids = [2,3] if isinstance(otherlimit, (int,float)) else otherlimit[1]
  for j in pair_ids: kb[j]=(-kmax,kmax)
 bd=[(Lmin,Lmax)]*4+kb+[(cmin,100.)]*24
 xx=np.clip(np.asarray(v0),np.array(bd)[:,0],np.array(bd)[:,1]);
 xx=np.r_[xx,max(0.15,evaluation(xx,T,Q,SMALL)['IL'])]
 def cons(xx):
  x=xx[:-1];t=xx[-1];out=[]
  for i,(fp,f2,f3) in enumerate(stage):
   xi=np.r_[x[:4],x[10+4*i:14+4*i],x[4:10]]
   p=transfer(xi,fp,*T,Q);h2=transfer(xi,f2,*T,Q);h3=transfer(xi,f3,*T,Q)
   out.extend(t-p);out.extend(h2-tar);out.extend(h3-tar)
  out.append(psd(x[4:10])-.001)
  return np.asarray(out)
 s=time.perf_counter()
 r=minimize(lambda z:z[-1],xx,bounds=bd+[(0.,4.)],constraints=[dict(type='ineq',fun=cons)],method='SLSQP',options=dict(maxiter=maxiter,ftol=2e-10,disp=False))
 x=r.x[:-1]; me=evaluation(x,T,Q,DENSE)
 m={**me, 'target':tar, 'kmax':kmax,'ILopt':float(r.x[-1]), 'x':x.tolist(),'PSD':float(psd(x[4:10])),'nit':int(r.nit),'success':bool(r.success), 'time':round(time.perf_counter()-s,2), 'otherlimit':otherlimit}
 m['valid']=bool(me['IL']<r.x[-1]+.001 and me['H2']>=tar-.002 and me['H3']>=tar-.002 and m['PSD']>=.0009)
 return m

if __name__=='__main__':
 store=[]
 for target in [35.05,33.,30.001]:
  s=seeds['base35'] if target>=35 else (np.array(next(d['x'] for d in front if d.get('coupling')=='all' and d.get('target')==33)) if target==33 else seeds['base30'])
  for km in [.25,.30,.35,.40,.50,.60]:
   st=time.monotonic()
   opts=[('warm',s)]
   if km>=.35 and target==35.05:opts.append(('previousK35',seeds['relax35']))
   best=None
   for tag,s0 in opts:
    m=tune(s0,target,km,maxiter=450)
    if best is None or (m['valid'] and (not best['valid'] or m['IL']<best['IL'])):best=m
   best['source']=tag
   if best['valid']:s=np.array(best['x'])
   print('RUN',target,km,round(best['IL'],6),round(best['H2'],4),round(best['H3'],4), 'valid',best['valid'],'PSDm',round(best['PSD'],3),'k',np.round(best['x'][4:10],3).tolist(),'dur',round(time.monotonic()-st,1), flush=True)
   store.append(best); json.dump(store,open(OUT+'/limits.json','w'),indent=2)
