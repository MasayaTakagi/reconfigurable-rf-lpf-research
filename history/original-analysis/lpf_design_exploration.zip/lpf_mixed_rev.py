import numpy as np, json,itertools,time
from scipy.optimize import differential_evolution,minimize
from lpf_mixed import calc,metr,obj,bounds,DENSE,LARGE
b=bounds.copy();b[1]=(2.4,3.1);b[3]=(1.65,2.05)
out=[]
for op in itertools.permutations('TPLC'):
 st=time.perf_counter();results=[]
 for seed in [37,88]:
  de=differential_evolution(obj,b,args=(op,30.05),seed=seed,maxiter=190,popsize=11,polish=True,tol=.003,atol=.0004)
  def con(y):
   z=calc(y[:-1],op,LARGE);return np.r_[y[-1]-z[:181],z[181:252]-30.05,z[252:]-30.05]
  zz=minimize(lambda y:y[-1],np.r_[de.x,metr(de.x,op)[0]+.04],bounds=b+[(0,25)],method='SLSQP',constraints={'type':'ineq','fun':con},options={'maxiter':200,'ftol':1e-10})
  x=zz.x[:-1] if zz.success and min(metr(zz.x[:-1],op)[2:])>=30.04999 else de.x
  m=metr(x,op)
  if min(m[2:])>=30.04999:results.append((m[0],x))
 if results:
  score,x=min(results,key=lambda x:x[0]);m=metr(x,op,DENSE);name=''.join(op)
  out.append({'name':name,'x':x.tolist(),'metrics':m})
  print('MIX_REV',name,round(m[0],6),np.round(m[2:],4),'x',np.round(x,5),'elapsed',round(time.perf_counter()-st,2),flush=True)
 else:print('MIX_REV',''.join(op),'NO FEAS',round(time.perf_counter()-st,2),flush=True)
 with open('/mnt/data/mixed_rev_corrected.json','w') as fw: json.dump(out,fw,indent=2)
