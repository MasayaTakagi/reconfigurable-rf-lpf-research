import os,sys,json,time
import numpy as np
from numba import njit
from scipy.optimize import minimize
sys.path[:0]=['/mnt/data/lpf_next']
from explore import SMALL,MED,DENSE,NAMES,COUPLES,three_series
B4,SER4,CE=three_series(2)
BASE=json.load(open('/mnt/data/lpf_phase2_extension/first.json'))
@njit(cache=True)
def transfer(L,k,LP,kp,C,fs,B,chipids):
 nP=len(LP);nN=B.shape[1];r=np.empty(len(fs),np.float64)
 for idx in range(len(fs)):
  w=2*np.pi*fs[idx]*1e6
  z=np.zeros((4+nP,4+nP),np.complex128)
  for i in range(4):
   z[i,i]=w*L[i]*1e-9*(1j+1/25.)
   if SER4[i]: z[i,i]+=(1/80.-1j)/(w*C[i]*1e-12)
  for i in range(nP):
   z[4+i,4+i]=w*LP[i]*1e-9*(1j+1/12.)+(1/80.-1j)/(w*C[4+i]*1e-12)
   a=chipids[i];v=1j*w*kp[i]*np.sqrt(L[a]*LP[i])*1e-9
   z[a,4+i]=v;z[4+i,a]=v
  for i in range(6):
   a=COUPLES[i,0];b=COUPLES[i,1];v=1j*w*k[i]*np.sqrt(L[a]*L[b])*1e-9
   z[a,b]=v;z[b,a]=v
  y=B.T@np.linalg.solve(z,B)
  for j in range(len(CE)):
   ci=CE[j,0];a=CE[j,1];b=CE[j,2];val=w*C[ci]*1e-12/(1/80.-1j)
   if a>=0:y[a,a]+=val
   if b>=0:y[b,b]+=val
   if a>=0 and b>=0:y[a,b]-=val;y[b,a]-=val
  y[0,0]+=1/50.;y[3,3]+=1/(60-40j)
  rhs=np.zeros(nN,np.complex128);rhs[0]=1/50.
  v=np.linalg.solve(y,rhs)
  eta=4*50*(60/5200)*abs(v[-1])**2
  r[idx]=-10*np.log10(max(eta,1e-99))
 return r

def kernel(pn,chipids,kval=.1):
 nP=len(pn);B=np.zeros((4+nP,4),np.complex128);B[:4]=B4
 for i,a in enumerate(pn): B[4+i,a]+=1
 return B,np.array(chipids,np.int64)

def psd(K,kp,cp):
 A=np.eye(4+len(kp))
 for i,(a,b) in enumerate(COUPLES):A[a,b]=A[b,a]=K[i]
 for i,a in enumerate(cp):A[a,4+i]=A[4+i,a]=kp[i]
 return float(np.linalg.eigvalsh(A)[0])

def optimize(pn,cp,initial_kp=None,init=None,maxiter=150,target=35.05,stage=SMALL,pcbmax=3.):
 nP=len(pn);D=4+nP;B,chip=kernel(pn,cp)
 bounds=[(.4,27)]*4+[(-.25,.25) if i in [2,3] else (-.16,.16) for i in range(6)]+[(.1,3)]*nP+[(-.16,.16)]*nP+[(.1,100)]*D*6
 base=np.array(BASE['x']);initkp=np.full(nP,.08) if initial_kp is None else np.asarray(initial_kp)
 x=np.r_[base[:10],np.full(nP,2.),initkp,np.array([np.r_[base[10+4*i:14+4*i],np.full(nP,1.)] for i in range(6)]).ravel()] if init is None else init
 x=np.clip(x,np.array(bounds)[:,0],np.array(bounds)[:,1]);z=np.r_[x,1.]
 def freq(x,j,f):return transfer(x[:4],x[4:10],x[10:10+nP],x[10+nP:10+2*nP],x[10+2*nP+j*D:10+2*nP+(j+1)*D],f,B,chip)
 def cons(z):
  x=z[:-1];t=z[-1];out=[]
  for j,(p,s,h) in enumerate(stage):out.extend(t-freq(x,j,p));out.extend(freq(x,j,s)-target);out.extend(freq(x,j,h)-target)
  out.append(psd(x[4:10],x[10+nP:10+2*nP],cp)-.01)
  return np.array(out)
 tim=time.time();r=minimize(lambda z:z[-1],z,method='SLSQP',bounds=bounds+[(0,6)],constraints=[dict(type='ineq',fun=cons)],options={'maxiter':maxiter,'ftol':3e-9})
 x=r.x[:-1];vals=[(float(max(freq(x,j,p))),float(min(freq(x,j,s))),float(min(freq(x,j,h)))) for j,(p,s,h) in enumerate(DENSE)]
 il=max(i[0] for i in vals);h2=min(i[1] for i in vals);h3=min(i[2] for i in vals)
 return dict(nodes=pn,chipids=cp,IL=il,H2=h2,H3=h3,feasible=bool(il<=r.x[-1]+.02 and h2>=target-.015 and h3>=target-.015 and psd(x[4:10],x[10+nP:10+2*nP],cp)>.009),x=x.tolist(),Lpcb=x[10:10+nP].tolist(),Kpcb=x[10+nP:10+2*nP].tolist(),sec=round(time.time()-tim,2),perband=dict(zip(NAMES,vals)),success=bool(r.success))

if __name__=='__main__':
 out=[];root='/mnt/data/lpf_pcb_expansion/coupled_results.json'
 targets=[([1,2],[2,3]),([1,2],[1,2]),([0,2],[0,2]),([1,3],[0,2]),([0,3],[0,3]),([1,2],[3,2]),([1,1],[1,2]),([1,2],[2,2]),([1,2],[0,1]),([2,3],[1,2])]
 for pn,cp in targets:
  x=optimize(pn,cp,maxiter=210)
  out.append(x);json.dump(out,open(root,'w'),indent=1)
  print('COUP',pn,cp,'IL',round(x['IL'],6),'H2',round(x['H2'],3),'H3',round(x['H3'],3),'ok',x['feasible'],'kpcb',np.round(x['Kpcb'],3),'Lpcb',np.round(x['Lpcb'],3),'t',x['sec'],flush=True)
 for r in sorted([x for x in out if x['feasible']],key=lambda o:o['IL'])[:3]:
  y=optimize(r['nodes'],r['chipids'],init=np.array(r['x']),stage=MED,maxiter=250)
  out.append(y);json.dump(out,open(root,'w'),indent=1)
  print('REFINE',r['nodes'],r['chipids'],'IL',round(y['IL'],6),'H2',round(y['H2'],3),'H3',round(y['H3'],3),'ok',y['feasible'],flush=True)
