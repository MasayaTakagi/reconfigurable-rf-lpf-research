import numpy as np,json,time
from scipy.optimize import minimize
from run_4L import *
orig=json.load(open('/mnt/data/lpf_sixband/phase2_four.json'))
starts=[r for r in orig if r['topology']=='4L4C_IN']
allruns=[]
for j,rec in enumerate(starts):
 for target in [30.0002,30.02]:
  x=np.array(rec['params']);init=np.r_[x,rec['metrics']['max_IL']+.01];t=time.time()
  def cc(y):return cons(y,False)-(np.r_[np.zeros(len(cons(y,False))-1),0.]) if False else cons(y,False) # target fixed in cons
  res=minimize(lambda y:y[-1],init,method='SLSQP',bounds=BND4+[(0,5)],constraints={'type':'ineq','fun':cc},options={'maxiter':360,'ftol':1e-10})
  metrics=getval(res.x[:-1],False);vv=float(min(cc(res.x)))
  outcome={'init':rec['init'],'mincon':vv,'success':bool(res.success),'niter':int(res.nit),'params':res.x[:-1].tolist(),'metrics':metrics}
  allruns.append(outcome)
  print('init',rec['init'],'target',target,'IL',metrics['max_IL'],'mincon',vv,'nit',res.nit,'time',round(time.time()-t,1),flush=True)
  with open('/mnt/data/lpf_sixband/phase2_four_continued.json','w') as f:json.dump(allruns,f,indent=2)
