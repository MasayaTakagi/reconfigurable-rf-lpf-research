import sys,json,numpy as np
sys.path.insert(0,'/mnt/data/lpf_pcb_expansion')
from coupled_pcb import optimize
j=json.load(open('/mnt/data/lpf_pcb_expansion/coupled_three_results.json'))
best=min((r for r in j if r['feasible'] and r['nodes']==[1,1,1] and r['chipids']==[1,2,3]),key=lambda r:r['IL']);x=np.asarray(best['x']);N=3;D=7

def grow(kinit=.06,cinit=1.0,linit=2.4):
 return np.r_[x[:10],x[10:13],linit,x[13:16],kinit,np.array([np.r_[x[16+i*D:16+(i+1)*D],cinit] for i in range(6)]).ravel()]
out=[];f='/mnt/data/lpf_pcb_expansion/coupled_four_results.json'
for node in [0,1,2,3]:
 for cp in [0,1,2,3]:
  if (node,cp) not in [(1,0),(1,1),(1,2),(1,3),(2,0),(2,1),(2,3),(0,0),(0,1),(3,3)]:continue
  r=optimize([1,1,1,node],[1,2,3,cp],init=grow(),maxiter=240)
  out.append(r);json.dump(out,open(f,'w'),indent=1)
  print('FOUR',node,cp,'IL',round(r['IL'],6),'H2',round(r['H2'],3),'H3',round(r['H3'],3),'ok',r['feasible'],'LPCB',np.round(r['Lpcb'],3),'K',np.round(r['Kpcb'],3),flush=True)
for r in sorted([r for r in out if r['feasible']],key=lambda r:r['IL'])[:2]:
 rr=optimize(r['nodes'],r['chipids'],init=np.array(r['x']),stage=__import__('explore').MED,maxiter=300)
 out.append(rr);json.dump(out,open(f,'w'),indent=1)
 print('REFINE',rr['nodes'],rr['chipids'],'IL',round(rr['IL'],6),'H2',round(rr['H2'],3),'H3',round(rr['H3'],3),'ok',rr['feasible'],flush=True)
