import sys,json,os,numpy as np
sys.path.insert(0,'/mnt/data/lpf_pcb_expansion');from coupled_pcb import optimize
best=min((x for x in json.load(open('/mnt/data/lpf_pcb_expansion/coupled_results.json')) if x['feasible'] and x['nodes']==[1,1]),key=lambda x:x['IL'])
x=np.array(best['x']); n=2; d=4+n

def grow(cinit=1.3,kinit=.08,linit=2.7):
 return np.r_[x[:10],x[10:12],linit,x[12:14],kinit,np.array([np.r_[x[14+i*6:14+i*6+6],cinit] for i in range(6)]).ravel()]
# original two node1, third different nodes, coupling to chip
cases=[([1,1,1],[1,2,0]),([1,1,1],[1,2,3]),([1,1,2],[1,2,0]),([1,1,2],[1,2,1]),([1,1,2],[1,2,3]),([1,1,0],[1,2,0]),([1,1,0],[1,2,3]),([1,1,3],[1,2,0]),([1,1,3],[1,2,3])]
out=[]; f='/mnt/data/lpf_pcb_expansion/coupled_three_results.json'
for nodes,ids in cases:
 r=optimize(nodes,ids,init=grow(),maxiter=200)
 out.append(r);json.dump(out,open(f,'w'),indent=1)
 print('THREE',nodes,ids,'IL',round(r['IL'],6),'H2',round(r['H2'],3),'H3',round(r['H3'],3),'ok',r['feasible'],'Lpcb',np.round(r['Lpcb'],3),'kp',np.round(r['Kpcb'],3),'time',r['sec'],flush=True)
for r in sorted([r for r in out if r['feasible']],key=lambda r:r['IL'])[:3]:
 rr=optimize(r['nodes'],r['chipids'],init=np.array(r['x']),maxiter=300,stage=__import__('explore').MED)
 out.append(rr);json.dump(out,open(f,'w'),indent=1)
 print('REFINE',rr['nodes'],rr['chipids'],'IL',round(rr['IL'],6),'H2',round(rr['H2'],3),'H3',round(rr['H3'],3),'ok',rr['feasible'],flush=True)
