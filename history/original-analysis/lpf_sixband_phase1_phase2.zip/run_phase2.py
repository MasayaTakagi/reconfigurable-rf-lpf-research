import numpy as np, json, time
from scipy.optimize import differential_evolution, minimize
from lpf_sixband import *
from numba import njit
NAMES=list(BANDS)
SMALL=[freqs(b,False) for b in NAMES]
LARGE=[freqs(b,True) for b in NAMES]

# Full: [L1,L2,L3,k12,k13,k23,C1B71,C2B71,C3B71,...]
def from_flat(z,i,model='D+',reverse=False):
 x=np.empty(9)
 x[:3]=z[:3]
 x[3:6]=z[6+3*i:9+3*i]
 x[6:]=z[3:6]
 return x

def evaluate(z,topology='D+',coupled=True,dense=False,ret=False):
 k=z[3:6]
 if psd(k)<.01:return (1000+1000*abs(psd(k))) if not ret else None
 blocks=LARGE if dense else SMALL
 maxil=-100.; violation=0.; details=[]
 for i,b in enumerate(NAMES):
  x=from_flat(z,i)
  if topology=='D+':F=lambda ff:il_three(x,ff,coupled,False,True)
  elif topology=='D':F=lambda ff:il_three(x,ff,coupled,False,False)
  elif topology=='D+_reverse':F=lambda ff:il_three(x,ff,coupled,True,True)
  fp,f2,f3=blocks[i]
  passIL=F(fp);s2=F(f2);s3=F(f3)
  ilmax=float(np.max(passIL));a2=float(np.min(s2));a3=float(np.min(s3))
  maxil=max(maxil,ilmax)
  violation+=max(0,30.-a2)**2+max(0,30.-a3)**2
  if ret: details.append(dict(band=b,max_IL=ilmax,mean_IL=float(np.mean(passIL)),stop2=a2,stop3=a3,L=x[:3].tolist(),C=x[3:6].tolist()))
 if ret:return dict(max_IL=maxil,penalty=violation,results=details,psd=float(psd(k)))
 return maxil + 20*violation

def first_guess(L=np.array([7.73066,8.61767,5.67967]),k=np.array([0.,0.,0.])):
 s=[]
 for b in NAMES:
  f=np.mean([np.mean(a) for a in BANDS[b]['ul']]); fac=(897.5/f)**2
  s += [0.68849*fac,.927977*fac,.60466*fac]
 return np.r_[L,k,s]

BND=[(1,27)]*3+[(-.45,.45)]*3+[(.15,6)]*18

def opt_joint(topology='D+',coupled=True,seed=11,iterations=500,init=None):
 bounds=BND.copy()
 if not coupled:bounds[3:6]=[(0,0)]*3
 x0=first_guess() if init is None else init.copy()
 initpop=np.array([np.random.default_rng(seed).uniform(lb,ub, len(bounds)) if lb!=ub else np.repeat(lb,len(bounds)) for lb,ub in bounds]).T # unused
 t=time.time();calls=[0]
 def fun(x):
  calls[0]+=1
  return evaluate(x,topology,coupled)
 de=differential_evolution(fun,bounds,popsize=6,maxiter=iterations,seed=seed,polish=True,tol=.001,init='latinhypercube',x0=np.clip(x0,[b[0] for b in bounds],[b[1] for b in bounds]))
 xx=de.x
 # refine on dense using objective penalty L-BFGS-B then SLSQP constrained
 opt=minimize(lambda z:evaluate(z,topology,coupled,True),xx,method='L-BFGS-B',bounds=bounds,options={'maxiter':400,'ftol':1e-10})
 if evaluate(opt.x,topology,coupled,True)<evaluate(xx,topology,coupled,True):xx=opt.x
 vals=evaluate(xx,topology,coupled,True,True)
 info=dict(topology=topology,coupled=coupled,x=xx.tolist(),detailed=vals,sec=round(time.time()-t,1),fun=float(de.fun),evals=calls[0],seed=seed)
 print(topology,'coupled',coupled,'seed',seed,'time',info['sec'],'max',round(vals['max_IL'],4),'penalty',round(vals['penalty'],4),'optfun',round(de.fun,4),'evals',calls[0],flush=True)
 for v in vals['results']:print(' ',v['band'], 'IL',round(v['max_IL'],4),'H2',round(v['stop2'],3),'H3',round(v['stop3'],3),'C',np.round(v['C'],3),flush=True)
 return info

if __name__=='__main__':
 print('checking scaled unoptimized:',evaluate(first_guess(),ret=True),flush=True)
 for c,t,seed,iters in [(False,'D+',10,280),(True,'D+',17,450),(True,'D+_reverse',9,360),(False,'D',12,180)]:
  res=opt_joint(t,c,seed,iters)
  p='/mnt/data/lpf_sixband/phase2_joint.json'
  old=[]
  try:old=json.load(open(p))
  except:pass
  old.append(res);open(p,'w').write(json.dumps(old,indent=2))
