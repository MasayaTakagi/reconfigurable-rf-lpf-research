import numpy as np,json,time
from scipy.optimize import minimize,differential_evolution
from run_phase2 import *
from lpf_sixband import *
entries=json.load(open('/mnt/data/lpf_sixband/phase2_multistart.json'))
base=min([r for r in entries if r['viol']>-0.0001], key=lambda r:r['metrics']['max_IL'])
BND4=[(1,27)]*4 +[(-.45,.45)]*3+sum([[(.15,6),(.15,6),(.15,6),(.005,8)] for i in range(6)],[])
assert len(BND4)==31

def convert3to4(x,L4=4.,C4=.03):
 z=np.r_[x[:3],L4,x[3:6]]
 for i in range(6):z=np.r_[z,x[6+3*i:9+3*i],C4]
 return z

def to_x4(z,i):
 return np.r_[z[:4],z[7+4*i:11+4*i],z[4:7]]

def getval(z,out=True,dense=True):
 block=LARGE if dense else SMALL
 vals=[]
 for i,b in enumerate(NAMES):
  x=to_x4(z,i); f,f2,f3=block[i]
  p=il_four(x,f,out); s2=il_four(x,f2,out);s3=il_four(x,f3,out)
  vals.append({'band':b,'max_IL':float(max(p)),'mean_IL':float(np.mean(p)),'stop2':float(min(s2)),'stop3':float(min(s3)),'C':x[4:8].tolist()})
 return dict(max_IL=max(v['max_IL'] for v in vals),worststop=min(min(v['stop2'],v['stop3']) for v in vals),results=vals)

def cons(y,out,block=LARGE):
 z=y[:-1]; result=[]
 for i,b in enumerate(NAMES):
  f,s2,s3=block[i];x=to_x4(z,i)
  pr=il_four(x,f,out);h2=il_four(x,s2,out);h3=il_four(x,s3,out)
  result.extend(y[-1]-pr);result.extend(h2-30.0002);result.extend(h3-30.0002)
 result.append(psd(z[4:7])-.005)
 return np.array(result)

if __name__=='__main__':
 outs=[]
 src=np.array(base['params'])
 for out in [False,True]:
  for j,(L4,C4) in enumerate([(3,.015),(10,.1),(3,2.)]):
   init=convert3to4(src,L4,C4)
   t=time.time()
   x0=np.r_[init,max(getval(init,out)['max_IL']+.2,.5)]
   res=minimize(lambda y:y[-1],x0,method='SLSQP',bounds=BND4+[(0,5)],constraints={'type':'ineq','fun':lambda y:cons(y,out)},options={'maxiter':120,'ftol':1e-9})
   result=getval(res.x[:-1],out); worst=float(min(cons(res.x,out)))
   rec={'topology':'4L4C_OUT' if out else '4L4C_IN','init':[L4,C4],'success':bool(res.success),'niter':int(res.nit),'feasible':worst>=-0.001,'mincon':worst,'seconds':round(time.time()-t,2),'params':res.x[:-1].tolist(),'metrics':result}
   outs.append(rec)
   print(rec['topology'],rec['init'],'maxIL',round(result['max_IL'],6),'stop',round(result['worststop'],4),'mincon',round(worst,5),'nit',res.nit,'secs',rec['seconds'],flush=True)
   open('/mnt/data/lpf_sixband/phase2_four.json','w').write(json.dumps(outs,indent=2))
