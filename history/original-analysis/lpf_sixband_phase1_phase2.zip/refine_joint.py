import numpy as np,json,time
from scipy.optimize import minimize
from run_phase2 import *
J='/mnt/data/lpf_sixband/phase2_joint.json'
archive=json.load(open(J)); out=[]
for rec in archive:
 x=np.array(rec['x']); name=rec['topology'];coupled=rec['coupled']
 print('start',name,coupled,flush=True)
 start=time.time()
 bounds=BND.copy()
 if not coupled:bounds[3:6]=[(0,0)]*3
 def fi(x,block):
  vals=[]
  for i, (fp,f2,f3) in enumerate(block):
   p=from_flat(x,i)
   if name=='D+':fn=lambda f:il_three(p,f,coupled,False,True)
   elif name=='D':fn=lambda f:il_three(p,f,coupled,False,False)
   else:fn=lambda f:il_three(p,f,coupled,True,True)
   vals.append(tuple(map(fn,(fp,f2,f3))))
  return vals
 def con(y):
  v=fi(y[:-1],LARGE);g=[]
  for passr,s2,s3 in v:
   g.extend(y[-1]-passr);g.extend(s2-30.0001);g.extend(s3-30.0001)
  g.append(psd(y[3:6])-.005)
  return np.array(g)
 ini=np.r_[x,max(evaluate(x,name,coupled,True,True)['max_IL'],.1)+.3]
 # SLSQP, large vector with finite difference
 rr=minimize(lambda y:y[-1],ini,method='SLSQP',bounds=bounds+[(0,15)],constraints={'type':'ineq','fun':con},options={'maxiter':170,'ftol':1e-9})
 x2=rr.x[:-1]; v2=evaluate(x2,name,coupled,True,True)
 v1=evaluate(x,name,coupled,True,True)
 print('result',name,coupled,'SLSQP status',rr.success,rr.message,'niter',rr.nit, 'init',v1['max_IL'],v1['penalty'],'new',v2['max_IL'],v2['penalty'],'worstcon',np.min(con(rr.x)),'time',round(time.time()-start,1),flush=True)
 # take only if feasible not worse
 if np.min(con(rr.x))>=-0.002 and (v1['penalty']>1e-5 or v2['max_IL']<v1['max_IL']):
  rec['x']=x2.tolist();rec['detailed']=v2;rec['refined']=True
 else:rec['refined']=False
 out.append(rec)
 open('/mnt/data/lpf_sixband/phase2_joint_refined.json','w').write(json.dumps(out,indent=2))
