import numpy as np,json,time
from scipy.optimize import minimize
from run_phase2 import *
records=json.load(open('/mnt/data/lpf_sixband/phase2_joint_refined.json'))
base=[r for r in records if r['topology']=='D+' and not r['coupled']][0]
coupled=[r for r in records if r['topology']=='D+' and r['coupled']][0]
reverse=[r for r in records if r['topology']=='D+_reverse'][0]

def unflip(z):
 y=z.copy();y[1],y[2]=z[2],z[1];y[3],y[4]=z[4],z[3]
 for i in range(6):y[7+i*3],y[8+i*3]=z[8+i*3],z[7+i*3]
 return y

bounds=BND.copy();fp=LARGE

def ilf(x,i):
 p=from_flat(x,i)
 return tuple(il_three(p,f,True) for f in fp[i])

def constraints(y):
 x=y[:-1];vals=[]
 for i in range(6):
  pa,s2,s3=ilf(x,i)
  vals.extend(y[-1]-pa); vals.extend(s2-30.0002);vals.extend(s3-30.0002)
 vals.append(psd(x[3:6])-.005)
 return np.array(vals)

starts=[('uncoupled',np.array(base['x'])),('coupled',np.array(coupled['x'])),('flipped',unflip(np.array(reverse['x'])))]
rng=np.random.default_rng(5)
for i in range(18):
 src=starts[i%3][1].copy()
 src[:3]*=rng.uniform(.75,1.25,3)
 src[3:6]+=rng.normal(0,.1,3)
 src[6:]*=rng.uniform(.8,1.2,18)
 src=np.clip(src,np.array(bounds)[:,0],np.array(bounds)[:,1])
 starts.append((f'jitter{i}',src))

winners=[]
for ii,(name,x) in enumerate(starts):
 initial=np.r_[x,max(0.4,evaluate(x,'D+',True,True,True)['max_IL'])+.5]
 t=time.time()
 res=minimize(lambda a:a[-1],initial,method='SLSQP',constraints={'type':'ineq','fun':constraints},bounds=bounds+[(0.,5.)],options={'maxiter':220,'ftol':1e-9})
 score=evaluate(res.x[:-1],'D+',True,True,True)
 constraint=float(np.min(constraints(res.x)))
 winners.append(dict(start=name,success=bool(res.success),viol=constraint,params=res.x[:-1].tolist(),metrics=score,time=round(time.time()-t,3),nit=res.nit))
 print(ii,name,'IL',round(score['max_IL'],6),'v',round(constraint,6),'feasible',constraint>-1e-4,'nit',res.nit,flush=True)
 open('/mnt/data/lpf_sixband/phase2_multistart.json','w').write(json.dumps(winners,indent=2))
