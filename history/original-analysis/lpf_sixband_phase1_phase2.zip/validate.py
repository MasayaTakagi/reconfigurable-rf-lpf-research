import numpy as np,json,csv
from lpf_sixband import *
from run_4L import *
from run_phase2 import *

def bands_grid(b,step=.2):
 d=BANDS[b]
 def arr(s,factor):
  return np.concatenate([np.linspace(lo*factor,hi*factor,int(np.ceil((hi-lo)*factor/step))+1) for lo,hi in s])
 return arr(d['ul'],1),arr(d['dl'],1),arr(d['ul'],2),arr(d['ul'],3)

four=json.load(open('/mnt/data/lpf_sixband/phase2_four_continued.json'))
four=min([r for r in four if r['mincon']>-1e-4],key=lambda a:a['metrics']['max_IL'])
joint=json.load(open('/mnt/data/lpf_sixband/phase2_multistart.json'))
three=min([r for r in joint if r['viol']>-1e-4],key=lambda a:a['metrics']['max_IL'])
uncoup=json.load(open('/mnt/data/lpf_sixband/phase2_joint_refined.json'))[0]

def resp(z, topology,name,freq):
 if topology=='4L4C':return il_four(to_x4(z,NAMES.index(name)),freq,False)
 if topology=='3L3C':return il_three(from_flat(z,NAMES.index(name)),freq,True)
 if topology=='3L3C_unc':return il_three(from_flat(z,NAMES.index(name)),freq,False)
 raise ValueError

models=[('4L4C',np.array(four['params'])),('3L3C',np.array(three['params'])),('3L3C_unc',np.array(uncoup['x']))]
allrows=[]
for mod,z in models:
 print('\nmodel',mod,'fixed L',z[:4 if mod=='4L4C' else 3], 'k',z[4:7] if mod=='4L4C' else z[3:6],flush=True)
 for band in NAMES:
  fp,fd,s2,s3=bands_grid(band,.1)
  p=np.r_[resp(z,mod,band,fp),resp(z,mod,band,fd)]
  h2=resp(z,mod,band,s2);h3=resp(z,mod,band,s3)
  row=dict(model=mod,band=band,max_IL=float(p.max()),mean_IL=float(p.mean()),min_H2=float(h2.min()),min_H3=float(h3.min()),H2_freq=float(s2[np.argmin(h2)]),H3_freq=float(s3[np.argmin(h3)]))
  allrows.append(row)
  print(band,'maxIL %.5f H2 %.5f H3 %.5f at %.2f/%.2f MHz'% (row['max_IL'],row['min_H2'],row['min_H3'],row['H2_freq'],row['H3_freq']),flush=True)
with open('/mnt/data/lpf_sixband/dense_validation.csv','w',newline='') as fh:
 writer=csv.DictWriter(fh,fieldnames=list(allrows[0]));writer.writeheader();writer.writerows(allrows)
