from lpf_mixed import calc as mc, metr as mm, obj as mo, bounds as mb
from lpf_pp import calc as pc, met as pm, obj as po, bounds as pb
from lpf_expand import LARGE,DENSE
from scipy.optimize import differential_evolution,minimize
import numpy as np,json
OUT=[]
for typ,ops,b,cf,me,ob in [('mixed',tuple('LTPC'),mb,mc,mm,mo),('twoparallel',tuple('3CL2'),pb,pc,pm,po)]:
 best=None
 for seed in [12,32,52,95]:
  de=differential_evolution(ob,b,args=(ops,35.),seed=seed,maxiter=310,popsize=14,polish=True,tol=.002)
  def con(y):
   rr=cf(y[:-1],ops,LARGE);return np.r_[y[-1]-rr[:181],rr[181:252]-35,rr[252:]-35]
  sl=minimize(lambda y:y[-1],np.r_[de.x,me(de.x,ops)[0]+.05],bounds=b+[(0,50)],method='SLSQP',constraints={'type':'ineq','fun':con},options={'maxiter':300,'ftol':1e-10})
  y=sl.x[:-1] if sl.success and min(me(sl.x[:-1],ops)[2:])>35-1e-4 else de.x
  m=me(y,ops,DENSE)
  if min(m[2:])>=35-1e-4 and (best is None or m[0]<best[0]):best=(m[0],y,m)
  print(typ,seed,sl.success,'IL',m[0],'stops',m[2:],flush=True)
 if best:
  o={'name':typ,'ops':ops,'components':best[1].tolist(),'metrics':best[2]};OUT.append(o)
  print('BEST_35',o,flush=True)
 with open('/mnt/data/mixedpp_35.json','w') as fw:json.dump(OUT,fw,indent=2)
