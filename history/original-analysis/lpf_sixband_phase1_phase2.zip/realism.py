import json,numpy as np,time
from scipy.optimize import minimize
from run_4L import *
results=json.load(open('/mnt/data/lpf_sixband/phase2_four_continued.json'))
seed=min([r for r in results if r['mincon']>-1e-4],key=lambda a:a['metrics']['max_IL'])
others=json.load(open('/mnt/data/lpf_sixband/phase2_four.json'))
seed2=[a for a in others if a['topology']=='4L4C_IN' and a['init']==[10,.1]][0]
allruns=[]
for minC,maxk,maxL in [(.3,.45,27),(.3,.25,27),(.5,.25,27)]:
 bounds=[(1.,maxL)]*4+[(-maxk,maxk)]*3+sum([[(minC,6.)]*4 for i in range(6)],[])
 for initname,orig in [('best',seed),('alternate',seed2)]:
  x=np.array(orig['params']);x=np.clip(x,np.array(bounds)[:,0],np.array(bounds)[:,1])
  y=np.r_[x,getval(x,False)['max_IL']+.5]
  t=time.time();rr=minimize(lambda z:z[-1],y,method='SLSQP',bounds=bounds+[(0,10)],constraints={'type':'ineq','fun':lambda z:cons(z,False)},options={'maxiter':200,'ftol':1e-9})
  val=getval(rr.x[:-1],False);v=float(np.min(cons(rr.x,False)))
  rec={'minC':minC,'maxk':maxk,'maxL':maxL,'start':initname,'feasible':v>-1e-4,'mincon':v,'metrics':val,'params':rr.x[:-1].tolist(),'nit':int(rr.nit)}
  allruns.append(rec)
  print('Cmin',minC,'kmax',maxk,'Lmax',maxL,initname,'IL',round(val['max_IL'],4),'Hmin',round(val['worststop'],3),'violation',round(v,4),'nit',rr.nit,'time',round(time.time()-t,2),flush=True)
  open('/mnt/data/lpf_sixband/physical_screen.json','w').write(json.dumps(allruns,indent=2))
