import sys,json,numpy as np,csv
sys.path[:0]=['/mnt/data/lpf_newwork','/mnt/data/lpf_sixband','/mnt/data/lpf_review']
from alt_topology import IL_3node, xpar
from lpf_sixband import BANDS
from decomposition import decomp
from run_4L import to_x4
from opt_compare import base4
from math import pi

def calc(x,f,ql1=25.,ql4=25.,pavs=1.0):
 L1,L2,L3,L4,C1,C2,C3,C4,k12,k13,k23=x
 w=2*pi*f*1e6
 Z=np.diag([(1/ql1+1j)*w*L1*1e-9,(1/25+1j)*w*L2*1e-9+(1/80-1j)/(w*C2*1e-12),(1/25+1j)*w*L3*1e-9+(1/80-1j)/(w*C3*1e-12)]).astype(complex)
 for k,m,n in [(k12,0,1),(k13,0,2),(k23,1,2)]:Z[m,n]=Z[n,m]=1j*w*k*np.sqrt(x[m]*x[n])*1e-9
 B=np.array([[1.,-1.,0.],[1.,0.,0.],[0.,0.,1.]])
 Y=B.T@np.linalg.solve(Z,B)
 zcap=lambda C:(1/80-1j)/(w*C*1e-12)
 z4=(1/ql4+1j)*w*L4*1e-9
 def stamp(yn,a,b,zz):
  yn[a,a]+=1/zz;yn[b,b]+=1/zz;yn[a,b]-=1/zz;yn[b,a]-=1/zz
 stamp(Y,0,1,zcap(C1));stamp(Y,1,2,z4);stamp(Y,1,2,zcap(C4))
 vsrc=np.sqrt(4*50*pavs)
 vin,yin=np.linalg.solve(Y+np.diag([1/50,0,1/(60-40j)]),np.array([vsrc/50,0,0],dtype=complex)), Y
 currents=np.linalg.solve(Z,B@vin)
 i4=(vin[1]-vin[2])/z4
 ic1=(vin[0]-vin[1])/zcap(C1)
 ic4=(vin[1]-vin[2])/zcap(C4)
 il=[abs(currents[j])**2*w*L*1e-9/(ql1 if j==0 else 25) for j,L in enumerate([L1,L2,L3])]+[abs(i4)**2*w*L4*1e-9/ql4]
 pc=[abs(ic1)**2/(w*C1*1e-12*80),abs(currents[1])**2/(w*C2*1e-12*80),abs(currents[2])**2/(w*C3*1e-12*80),abs(ic4)**2/(w*C4*1e-12*80)]
 pout=abs(vin[2])**2*np.real(1/(60-40j))
 i_in=(vsrc-vin[0])/50
 s11=(vin[0]/i_in-50)/(vin[0]/i_in+50)
 pin=pavs*(1-abs(s11)**2)
 loss_power=sum(il)+sum(pc)
 return dict(IL=-10*np.log10(pout/pavs),ILmis=-10*np.log10(pin/pavs),ILloss=10*np.log10(pin/pout),Pin=pin,Pout=pout,Pdiss=loss_power,ball=pin-pout-loss_power,L1=il[0],L2=il[1],L3=il[2],L4=il[3],C1=pc[0],C2=pc[1],C3=pc[2],C4=pc[3],I1=abs(currents[0]),I2=abs(currents[1]),I3=abs(currents[2]),I4=abs(i4),volts=list(map(float,np.abs(vin))))

r=json.load(open('/mnt/data/lpf_newwork/refined_results.json'))
rows=[]
for k,q1,q4 in [(0,25,25),(1,30,25),(2,30,30)]:
 for i,band in enumerate(BANDS):
  f=max([b for a,b in BANDS[band]['ul']+BANDS[band]['dl']])
  x=xpar(np.asarray(r[k]['x']),i)
  a=calc(x,f,q1,q4)
  print('NEW',q1,q4,band,f,'IL',round(a['IL'],5),'pL_W',np.round([a[f'L{j}'] for j in range(1,5)],5),'pC_W',np.round([a[f'C{j}'] for j in range(1,5)],5),'Irms',np.round([a[f'I{j}']*1000 for j in range(1,5)],1),'balance',round(a['ball'],7),flush=True)
  rows.append(dict(layout='two_series',q1=q1,q4=q4,band=band,f=f,**{k:v for k,v in a.items() if k!='volts'}))
for i,band in enumerate(BANDS):
 f=max([b for a,b in BANDS[band]['ul']+BANDS[band]['dl']])
 old=decomp(to_x4(np.array(base4['params']),i),f)
 print('OLD',band,f,'IL',round(old['IL'],5),'pL',np.round(old['psL'],4),'pC',np.round(old['psC'],4),'balance',round(old['p_balance'],7),flush=True)
rows=[{k:v for k,v in row.items()} for row in rows]
with open('/mnt/data/lpf_newwork/loss_breakdown.csv','w',newline='') as file:
 writer=csv.DictWriter(file,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
