import numpy as np,sys, json,itertools,time
from scipy.optimize import differential_evolution,minimize
from lpf_expand import SMALL,LARGE,DENSE,RS,ZD,K

# Mixed hybrid: one shunt series LC trap (T), one series parallel LC block (P), L series, C shunt
# x = [Lt,ft,Lp,fp,Ls,Cs], all L<=27 all C<=100
bounds=[(.15,27),(1.65,2.05),(.15,27),(2.40,3.10),(.01,27),(.01,100)]

def calc(x,ops, f=SMALL):
    lt,ft,lp,fp,ls,cs=x
    w=2*np.pi*f
    zl=lambda L:w*L*1e-9*(.04+1j)
    zc=lambda C:(.0125-1j)/(w*C*1e-12)
    zt=zl(lt)+zc(K/(lt*ft*ft));zpp=zl(lp)*zc(K/(lp*fp*fp))/(zl(lp)+zc(K/(lp*fp*fp)))
    zls=zl(ls);ycs=1/zc(cs)
    a=np.ones_like(w,dtype=complex);b=np.zeros_like(w,dtype=complex);c=np.zeros_like(w,dtype=complex);d=np.ones_like(w,dtype=complex)
    for typ in ops:
        if typ in 'TP':
            if typ=='T':y=1/zt; a=a+b*y;c=c+d*y
            else: z=zpp;b=a*z+b;d=c*z+d
        elif typ=='L':
            b=a*zls+b;d=c*zls+d
        else:
            a=a+b*ycs;c=c+d*ycs
    den=a*ZD+b+RS*(c*ZD+d)
    return -10*np.log10(np.clip(4*RS*ZD.real/np.abs(den)**2,1e-100,1))

def obj(x,ops,target=30.05):
    r=calc(x,ops);p=r[:37];s2=r[37:52];s3=r[52:]
    return float(p.max()+45*(max(0,target-s2.min())**2+max(0,target-s3.min())**2))

def metr(x,ops,f=LARGE):
    rr=calc(x,ops,f);n=np.sum(f<1e9);m=np.sum((f>1e9)&(f<2e9));return [float(rr[:n].max()),float(rr[:n].mean()),float(rr[n:n+m].min()),float(rr[n+m:].min())]

def sls(x,ops,target,bounds_override=None):
    def con(y):
        rr=calc(y[:-1],ops,LARGE)
        return np.r_[y[-1]-rr[:181],rr[181:252]-target,rr[252:]-target]
    return minimize(lambda y:y[-1],np.r_[x,metr(x,ops)[0]+.01],bounds=(bounds_override if bounds_override is not None else bounds)+[(0,25)],method='SLSQP',constraints={'type':'ineq','fun':con},options={'maxiter':250,'ftol':1e-10})

if __name__=='__main__':
 target=float(sys.argv[1]) if len(sys.argv)>1 else 30.05
 out=[]
 for rev in [False,True]:
  for i,op in enumerate(itertools.permutations('TPLC')):
   # where rev T tuned to 3f, P tuned to 2f
   if rev:
    boundst=bounds.copy();boundst[1]=(2.4,3.1);boundst[3]=(1.65,2.05)
   else:boundst=bounds
   st=time.perf_counter();results=[]
   for seed in [31,73]:
    de=differential_evolution(obj,boundst,args=(op,target),seed=seed,maxiter=210,popsize=11,polish=True,tol=.003,atol=.0004)
    s=sls(de.x,op,target,boundst)
    good=s.success and min(metr(s.x[:-1],op)[2:])>target-1e-4
    if good:results.append((metr(s.x[:-1],op)[0],s.x[:-1],True))
    else:
     met=metr(de.x,op)
     if min(met[2:])>=target-1e-4:results.append((met[0],de.x,False))
   if results:
    score,x,ok=min(results,key=lambda a:a[0]);mm=metr(x,op,DENSE)
    entry={'name':''.join(op)+('_rev' if rev else ''),'x':x.tolist(),'metrics':mm,'success':ok,'ct':K/(x[0]*x[1]**2),'cp':K/(x[2]*x[3]**2)}
    out.append(entry)
    print('MIXED',entry['name'],'il',round(mm[0],6),'s2',round(mm[2],4),'s3',round(mm[3],4),'values',np.round(x,6),'Ct',round(entry['ct'],5),'Cp',round(entry['cp'],5),'sec',round(time.perf_counter()-st,2),flush=True)
   else:
    print('MIXED', ''.join(op)+('_rev' if rev else ''),'no feasible','sec',round(time.perf_counter()-st,2),flush=True)
   with open('/mnt/data/mixed_'+str(target)+'.json','w') as fh:json.dump(out,fh,indent=2)
