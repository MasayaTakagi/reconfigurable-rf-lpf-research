import json,os,sys
import numpy as np
from scipy.optimize import minimize_scalar
from explore import *
results={'tight':json.load(open('/mnt/data/lpf_next/tight.json')),'frontier':json.load(open('/mnt/data/lpf_next/frontier.json')),'two':json.load(open('/mnt/data/lpf_next/two.json'))}
q=np.array([25.,25.,25.,25.,80.]);tp=three_series(2)
def dense_grid(name,which,step=.05):
 b=BANDS[name]; base=b['ul']+b['dl'] if which=='pass' else b['ul']; mult={'pass':1,'H2':2,'H3':3}[which]
 return [(float(a*mult),float(b*mult),np.arange(a*mult,b*mult+step/2,step)) for a,b in base]
def extrema(x,i,which):
 c=np.asarray(x[10+4*i:14+4*i]);z=np.r_[x[:4],c,x[4:10]]; fn=lambda f:float(transfer(z,np.array([f]),*tp,q)[0]); maximize=which=='pass'; raw=[]
 for lo,hi,ff in dense_grid(NAMES[i],which):
  vv=transfer(z,ff,*tp,q)
  idx=[0,len(ff)-1]
  for j in range(1,len(ff)-1):
   if maximize:
    if vv[j]>=vv[j-1] and vv[j]>=vv[j+1]:idx.append(j)
   else:
    if vv[j]<=vv[j-1] and vv[j]<=vv[j+1]:idx.append(j)
  for j in idx:
   if j==0 or j==len(ff)-1: raw.append((float(ff[j]),float(vv[j])))
   else:
    ri=minimize_scalar((lambda f:-fn(f)) if maximize else fn,bounds=(ff[j-1],ff[j+1]),method='bounded',options={'xatol':1e-8})
    raw.append((float(ri.x),fn(float(ri.x))))
 return sorted(raw,key=lambda a:(-a[1] if maximize else a[1]))[0]

if __name__=='__main__':
 designs=[]
 designs.append(('new_35p10',next(d for d in results['tight'] if d['target']==35.1)))
 designs.append(('new_35p05',next(d for d in results['tight'] if d['target']==35.07)))
 designs.append(('new_33',next(d for d in results['frontier'] if d['target']==33 and d['coupling']=='all')))
 designs.append(('new_31',next(d for d in results['frontier'] if d['target']==31 and d['coupling']=='all')))
 designs.append(('two_34p5',next(d for d in results['two'] if d['target']==34.5)))
 designs.append(('old_34',dict(x=seed().tolist(),target=34)))
 designs.append(('nominal_30p001',next(d for d in json.load(open('/mnt/data/lpf_next/min30.json')) if d['target']==30.001)))
 rows=[]
 for nm,d in designs:
  x=np.array(d['x'])
  print('VERIFY',nm,'PSD',psd(x[4:10]),flush=True)
  for i,band in enumerate(NAMES):
   fpass,il=extrema(x,i,'pass');f2,h2=extrema(x,i,'H2');f3,h3=extrema(x,i,'H3')
   row=dict(design=nm,band=band,max_IL_dB=il,min_H2_dB=h2,min_H3_dB=h3,critical_pass_MHz=fpass,critical_H2_MHz=f2,critical_H3_MHz=f3)
   rows.append(row)
   print(band,round(il,6),round(h2,4),round(h3,4),flush=True)
 json.dump(rows,open('/mnt/data/lpf_next/continuous_scan.json','w'),indent=2)
