import json,csv,os,sys,zipfile
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from lpf_sixband import *
from run_4L import to_x4
from run_phase2 import from_flat,NAMES
P=Path('/mnt/data/lpf_sixband');
def read(p):return json.loads((P/p).read_text())
four_m= min((r for r in read('phase2_four_continued.json') if r['mincon']>-1e-4),key=lambda r:r['metrics']['max_IL'])
four_p=next(r for r in read('physical_screen.json') if r['feasible'] and r['minC']==.5 and r['start']=='best')
four_35=next(r for r in read('margins.json') if r['target']==35)
three=min((r for r in read('phase2_multistart.json') if r['viol']>-1e-4),key=lambda r:r['metrics']['max_IL'])
unc=next(r for r in read('phase2_joint_refined.json') if r['topology']=='D+' and not r['coupled'])
no_cap=next(r for r in read('phase2_joint_refined.json') if r['topology']=='D' and not r['coupled'])
models=[('D_3L2C',np.array(no_cap['x']),0),('Dplus_uncoupled_3L3C',np.array(unc['x']),1),('Dplus_coupled_3L3C',np.array(three['params']),2),('4L4C_ideal30',np.array(four_m['params']),3),('4L4C_screen30',np.array(four_p['params']),3),('4L4C_screen35',np.array(four_35['params']),3)]

def intervals(b,step=.1):
 d=BANDS[b]
 def fit(ranges,factor):return np.concatenate([np.linspace(a*factor,c*factor,int(np.ceil((c-a)*factor/step))+1) for a,c in ranges])
 return fit(d['ul'],1),fit(d['dl'],1),fit(d['ul'],2),fit(d['ul'],3)

def response(z,typ,i,f):
 if typ==3:return il_four(to_x4(z,i),f,False)
 return il_three(from_flat(z,i),f,typ==2,False,typ!=0)

rows=[];valrows=[]
for model,z,typ in models:
 for i,b in enumerate(NAMES):
  fpl,fpd,f2,f3=intervals(b,.1)
  pl=response(z,typ,i,fpl);pd=response(z,typ,i,fpd);h2=response(z,typ,i,f2);h3=response(z,typ,i,f3)
  d=dict(model=model,case=b,IL_UL_max_dB=float(max(pl)),IL_DL_max_dB=float(max(pd)),IL_max_dB=float(max(max(pl),max(pd))),H2_min_dB=float(min(h2)),H3_min_dB=float(min(h3)),H2_worst_MHz=float(f2[np.argmin(h2)]),H3_worst_MHz=float(f3[np.argmin(h3)]))
  rows.append(d)
  if typ==3:
   cs=z[7+i*4:11+i*4]
  else:cs=z[6+i*3:9+i*3]
  valrows.append(dict(model=model,case=b,L1_nH=z[0],L2_nH=z[1],L3_nH=z[2],L4_nH=z[3] if typ==3 else '',k12=z[4] if typ==3 else z[3],k13=z[5] if typ==3 else z[4],k23=z[6] if typ==3 else z[5],C1_pF=cs[0],C2_pF=cs[1],C3_pF=cs[2],C4_pF=cs[3] if typ==3 else ''))

def writecsv(filename,data):
 with open(P/filename,'w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
writecsv('comparison_dense_0p1MHz.csv',rows);writecsv('component_settings.csv',valrows)
# Summary txt
print('dense summaries')
for model,zz,typ in models:
 v=[r for r in rows if r['model']==model]
 print(model,'max IL',round(max(r['IL_max_dB'] for r in v),5),'minimum H2',round(min(r['H2_min_dB'] for r in v),5),'min H3',round(min(r['H3_min_dB'] for r in v),5))
# bar chart
ind=np.arange(len(NAMES));w=.21
fig,ax=plt.subplots(figsize=(10,4.8))
labels=['D+ 3L3C uncoupled','D+ 3L3C coupled','4L4C initial','4L4C screened 35dB']
names=['Dplus_uncoupled_3L3C','Dplus_coupled_3L3C','4L4C_ideal30','4L4C_screen35']
for j,(name,label) in enumerate(zip(names,labels)):
 vv=[next(r['IL_max_dB'] for r in rows if r['case']==b and r['model']==name) for b in NAMES]
 ax.bar(ind+(.5+j-2)*w,vv,w,label=label)
ax.set_xticks(ind,NAMES);ax.set_ylim(0,.73);ax.set_ylabel('Worst UL+DL insertion loss (dB)');ax.set_title('Six-band common-L, band-switched-C circuit comparison')
ax.grid(axis='y',alpha=.25);ax.legend(loc='upper right',fontsize=8,ncol=2)
fig.tight_layout();fig.savefig(P/'sixband_IL_comparison.png',dpi=190);plt.close(fig)
# B8/B28 best 35dB plots, at least zoom pass and stop
xx=np.array(four_35['params']);fig,axes=plt.subplots(3,1,figsize=(9,8.8),layout='constrained')
for b in ['B71','B28','B8']:
 i=NAMES.index(b); f1,fd,f2,f3=intervals(b,.4)
 p1=response(xx,3,i,f1);p2=response(xx,3,i,fd); h2=response(xx,3,i,f2);h3=response(xx,3,i,f3)
 axes[0].plot(f1,p1,label=b);axes[0].plot(fd,p2,color=axes[0].lines[-1].get_color())
 axes[1].plot(f2,h2,label=b);axes[2].plot(f3,h3,label=b)
axes[0].set_title('4L4C screened design, 35 dB nominal target')
axes[0].set_ylabel('Insertion loss (dB)');axes[0].set_xlim(600,970);axes[0].legend(ncol=3)
axes[1].set_ylabel('H2 attenuation (dB)');axes[1].set_xlim(1250,1900);axes[1].axhline(30,linestyle='--',color='gray');axes[1].legend(ncol=3)
axes[2].set_ylabel('H3 attenuation (dB)');axes[2].set_xlim(1900,2800);axes[2].axhline(30,linestyle='--',color='gray');axes[2].legend(ncol=3)
for ax in axes:ax.set_xlabel('Frequency (MHz)');ax.grid(alpha=.25)
fig.savefig(P/'sixband_response_35dB.png',dpi=180);plt.close(fig)

# README / roadmap
band_table='\n'.join('| '+b+' | '+','.join('%s-%s'%r for r in BANDS[b]['ul'])+' | '+','.join('%s-%s'%r for r in BANDS[b]['dl'])+' |' for b in NAMES)
md=f'''# Six-case LTE tunable notch LPF — Phase 1/2 numerical exploration

Date: 2026-10-10 (JST)

## Cases and definitions

| Case | UL MHz | DL MHz |
|---|---|---|
{band_table}

- Passbands are the **union** of that case's UL and DL intervals.
- Stopbands are exactly the **2x and 3x** frequency intervals of each case's UL.
- B13+14 is *one switch state* covering both bands (not one state per band).
- Rs = 50 ohms, Zload = 60 - j40 ohms for all frequencies.
- Loss is transducer insertion loss relative to available source power, including load mismatch.
- Nominal rejection >=30 dB for both stopbands.
- Initial model uses series R_L = omega*L/25 and series ESR_C = abs(X_C)/80.
- Capacitors are continuously adjustable in Phase 1/2, **not switched-bank hardware yet**.

## Topologies evaluated

1. D: input series LC shunt, series L, output series LC shunt (3L2C).
2. D+: same with parallel C across the series L (3L3C).
3. Coupled D+: magnetic mutuals between all three inductors (3L3C).
4. Added input LC trap: D+ plus one more shunt series-LC at input (4L4C, mutuals only among original 3 coils).
5. Added output LC trap: D+ plus one more shunt series-LC at output (4L4C, investigated but not selected).
6. Reversed D+ trap naming (tested, electrically isomorphic under complete relabeling).

The 4L4C model has L1 || C1 in the series path; shunt at input L2+C2 and L4+C4; shunt at output L3+C3. L4 is **not** coupled to L1/L2/L3 in this search.

L values in nH, C in pF. Shared fixed inductances and couplings across the six cases, but capacitors vary by case. The search was local and multistart, with continuous C, bounds 1-27 nH, >=0.15 pF for initial nominal candidates, |k|<=0.45, PSD coupling matrix. The screening case tightened to C>=0.5 pF and |k|<=0.25; these constraints are assumptions, not real component ratings.

## Representative candidates, 0.1 MHz validation

| Topology | Worst passband IL, dB | Global min H2, dB | Global min H3, dB |
|---|---:|---:|---:|
'''
for model,z,typ in models:
 v=[r for r in rows if r['model']==model]
 md+=f"| {model} | {max(r['IL_max_dB'] for r in v):.6f} | {min(r['H2_min_dB'] for r in v):.6f} | {min(r['H3_min_dB'] for r in v):.6f} |\n"
md+='''
**Important:** For Dplus_coupled_3L3C one 0.1 MHz validation point gives H3 just below 30.000 dB by less than 0.0001 dB; that near-boundary candidate does **not** strictly pass 30 dB without rounding or retuning. Other candidates must also be checked with true interval extrema, not merely a finite frequency grid.

## Phase 1 completed (single-band individual L/C/k)

- B71 D+ no coupling: ~0.398 dB maximum IL; coupled: ~0.342 dB.
- B8 D+ no coupling: ~0.397 dB maximum IL; coupled: ~0.341 dB.
- These are different optimized fixed-L values, so they cannot be naively used as a six-state common board.

## Phase 2 completed (selected topology family search)

- Six-state common circuit, all-band minimax IL with 30 dB nominal rejection.
- Uncoupled D+: ~0.471 dB.
- Coupled D+: ~0.438 dB (needs ~0.0001 dB retuning for 0.1 MHz strict pass).
- 4L4C input-trap extension: ~0.328 dB optimistic continuous-C model.
- 4L4C screening with C>=0.5 pF, |k|<=0.25: ~0.396 dB at 30 dB target.
- Same screened 4L4C, 35 dB nominal target: ~0.439 dB.

These are **numerically found feasible candidates** on dense grids, not global minima, not guaranteed against tolerances.

## 4L4C screened 35 dB preferred design

Fixed components and coupling:
'''
x=np.array(four_35['params'])
for j in range(4):md+=f"- L{j+1} = {x[j]:.7f} nH\n"
for j,key in enumerate(['k12','k13','k23']):md+=f"- {key} = {x[4+j]:.7f}\n"
md+='\nBand-specific ideal C setting (pF):\n\n| Case | C1 | C2 | C3 | C4 |\n|---|---:|---:|---:|---:|\n'
for i,b in enumerate(NAMES):
 c=x[7+4*i:11+4*i];md+=f"| {b} | {c[0]:.5f} | {c[1]:.5f} | {c[2]:.5f} | {c[3]:.5f} |\n"
md+='''
## Roadmap, subsequent phases

- **Phase 3 — Switched-cap architecture:** identify actual RF switch/stack topology and capacitor technology, control codebook; optimize 3/4/5-bit banks including ON R, OFF C, nonlinear capacitance and bond/wiring parasitics. Pass when all six cases meet nominal 35 dB on realistic component models and the agreed IL target; determine switching settling/overshoot.
- **Phase 4 — Multi-band robust co-optimization:** jointly optimize topology/part selection, shared L, feasible k, and per-band integer switch codes; include Monte Carlo tolerances plus worst-case corners; ensure >=30 dB in specified PVT corners with margin, and bound continuous-frequency extrema.
- **Phase 5 — High power (>23 dBm):** user must set exact Pmax (e.g. 27/30/33 dBm), modulation and worst load VSWR. HB/PA co-simulation, voltage stress across series-cap banks including OFF branches, power loss/thermal, P1dB, IMD, EVM and ACLR as appropriate; check power-generated H2/H3 rather than only passive transducer IL.
- **Phase 6 — EM + parts:** layout coil relative orientation to realize K, self-resonances for high-L coils, RF switching isolation, ESD, ground return; EM-circuit co-optimization and PCB prototype.
- **Phase 7 — Test + bounded optimality:** characterize 6 settings UL and DL S-parameters, harmonic load pull under high power, temp/voltage/switch codes and PVT; enumerate bounded schematic/topology family, formal interval verification + validated global optimization when feasible.

## Constraints and status

- This **does not prove** global optimality across all L/C graphs. No bridge topologies or all 4-coil mutual combinations were exhaustively searched.
- k constraints were imposed by model but not validated against a specific physical coil placement. Eigenpositive inductance matrix is necessary but not sufficient for geometric realizability.
- Q_L=25 and Q_C=80 were held constant through 2.7 GHz. Actual 27 nH coils may have SRF below some harmonic frequencies; thus model improvement may not be realizable.
- Continuous ideal capacitor values are NOT realizable discrete switch-bank codes until Phase 3.
- Dense frequency sampling at 0.1 MHz is still not a mathematical proof of entire-band satisfaction.
- For 35 dB design, 5 dB is nominal model headroom only, NOT a demonstrated post-tolerance margin.

## How to reproduce

Run `python lpf_sixband.py test`. Run `run_phase1.py`, `run_phase2.py`, `refine_joint.py`, `run_4L.py`, `continue_4L.py`, `realism.py`, and `margin4.py` to replicate the search flow. Re-run `build_report.py` for summary CSV and plots. Requires numpy, scipy, numba, matplotlib. Differential evolution is seed sensitive; these numerical candidates are saved in the JSON files. Some experiments are stochastic/multistart and may not recover exactly identical outcomes.

The band data is from 3GPP TS 36.101 Table 5.5-1: https://itecspec.com/3gpp/36.101/s/5.5
'''
(P/'ROADMAP_AND_PHASE2_REPORT.md').write_text(md)
files=list(P.glob('*.py'))+list(P.glob('*.json'))+list(P.glob('*.csv'))+list(P.glob('*.png'))+[P/'ROADMAP_AND_PHASE2_REPORT.md']
with zipfile.ZipFile('/mnt/data/lpf_sixband_phase1_phase2.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(f,f.name)
print('files',len(files),'zip size',os.path.getsize('/mnt/data/lpf_sixband_phase1_phase2.zip'))
