#!/usr/bin/env python3
"""Operating-impedance Smith chart for the user's 3 coupled-L LPF designs.
Reads existing validated parameter tables. Finite-Q coupled inductor 4x4 impedance matrix;
normalizes voltages to a 1 V (rms) Thévenin source and 50 ohm source resistance.
The plotted points are v/I at physical cuts under *full* coupled circuit operation,
not independent cascaded ABCD sections; this distinction is essential.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
from matplotlib.lines import Line2D

OUT=Path('/mnt/data/lpf_smith_study');OUT.mkdir(parents=True,exist_ok=True)
F=Path('/mnt/data/lpf_three_design_comparison')
fixed=pd.read_csv(F/'fixed_L_and_couplings.csv')
caps=pd.read_csv(F/'six_band_capacitors_and_metrics.csv')
DESIGNS={'minimum_30p001':'A｜30 dB','balanced_33':'B｜33 dB','margin_35p10':'C｜35.1 dB'}
KP=['k12','k13','k14','k23','k24','k34']
LP=['L1_nH','L2_nH','L3_nH','L4_nH']
PAIRS=[(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]
BANDS={'B71':([663,698],[617,652]),'B12':([699,716],[729,746]),'B28':([703,748],[758,803]),'B13+14':([777,798],[746,768]),'B26':([814,849],[859,894]),'B8':([880,915],[925,960])}
Zref=50
Zload=60-40j
STAGE=['負荷 60−j40Ω', 'L3∥C3 通過後', 'L2–C2 分流後', 'L4∥C4 通過後', 'L1∥C1 通過後']
STAGE_COLORS=['#626a73','#3170A5','#2B9373','#C08035','#9B5BB3']
plt.rcParams['font.family']='Noto Sans CJK JP'
plt.rcParams['axes.unicode_minus']=False

def pars(design,band):
 d=fixed[fixed.design==design]
 p={r.parameter:r.value for r in d.itertuples()}
 c=caps[(caps.design==design)&(caps.band==band)].iloc[0]
 return np.array([p[x] for x in LP])*1e-9, np.array([p[x] for x in KP]), np.array([c[f'C{i}_pF'] for i in range(1,5)])*1e-12

def calc(design,band,f_mhz):
 L,ks,C=pars(design,band)
 w=2*np.pi*f_mhz*1e6
 B=np.zeros((4,4),float)
 B[0,0]=1; B[0,1]=-1
 B[1,2]=1
 B[2,2]=1; B[2,3]=-1
 B[3,1]=1; B[3,2]=-1
 Z=np.diag(w*L*(1/25+1j)).astype(complex)
 Zcap=(1/80-1j)/(w*C)
 Z[1,1]+=Zcap[1]
 for n,(i,j) in enumerate(PAIRS):Z[i,j]=Z[j,i]=1j*w*ks[n]*np.sqrt(L[i]*L[j])
 Y=B.T@np.linalg.solve(Z,B)
 for j,a,b in [(0,0,1),(3,1,2),(2,2,3)]:
  y=1/Zcap[j]
  Y[a,a]+=y;Y[b,b]+=y;Y[a,b]-=y;Y[b,a]-=y
 Y[0,0]+=1/50;Y[3,3]+=1/Zload
 v=np.linalg.solve(Y,np.array([1/50,0,0,0],complex))
 il=-10*np.log10(4*50*np.real(1/Zload)*abs(v[3])**2)
 i=np.linalg.solve(Z,B@v)
 I1=i[0]+(v[0]-v[1])/Zcap[0]
 I4=i[3]+(v[1]-v[2])/Zcap[3]
 I3=i[2]+(v[2]-v[3])/Zcap[2]
 Ish=i[1]
 Iout=v[3]/Zload
 assert abs(I1-I4)<1e-9 and abs(I4-I3-Ish)<1e-9
 Zin=np.array([Zload,v[2]/I3,v[2]/I4,v[1]/I4,v[0]/I1],complex)
 gamma=(Zin-50)/(Zin+50)
 paths=np.abs(np.diff(gamma))
 Lloss=np.abs(i)**2*w*L/25*200 # scaled to P_avs=1W
 Closs=np.zeros(4)
 Closs[1]=np.abs(i[1])**2*np.real(Zcap[1])*200
 for j,a,b in [(0,0,1),(3,1,2),(2,2,3)]:
  Closs[j]=np.abs(v[a]-v[b])**2*np.real(1/Zcap[j])*200
 reflection=np.abs(gamma[-1])**2
 trans=4*50*np.real(1/Zload)*abs(v[3])**2
 assert abs(reflection+trans+sum(Lloss)+sum(Closs)-1)<1e-8
 return {'Z':Zin,'g':gamma,'len':sum(paths),'segment_len':paths,'IL':il,'S11':gamma[-1], 'Lloss':Lloss,'Closs':Closs,'reflP':reflection,'transP':trans}

def gam(z):return (z-50)/(z+50)

def chart_grid(ax,labels=False):
 phi=np.linspace(0,2*np.pi,600)
 ax.plot(np.cos(phi),np.sin(phi),c='#374151',lw=1.4,zorder=1)
 for r in [0,0.2,0.5,1,2,5,10]:
  xc=r/(r+1); rad=1/(r+1)
  if r==0:continue
  xx=xc+rad*np.cos(phi); yy=rad*np.sin(phi)
  keep=(xx*xx+yy*yy<=1.00001)
  ax.plot(np.where(keep,xx,np.nan),np.where(keep,yy,np.nan),c='#D4D9DE',lw=0.75,zorder=0)
  if labels and r in [.2,.5,1,2,5]:
   rg=gam(50*r+0j).real
   ax.text(rg,.02,f'{r:g}',fontsize=7,color='#8A949E',ha='center')
 for x in [.2,.5,1,2,5,-.2,-.5,-1,-2,-5]:
  rr=np.geomspace(.001,1000,550)
  g=(rr+1j*x-1)/(rr+1j*x+1)
  ax.plot(g.real,g.imag,c='#D4D9DE',lw=.7,zorder=0)
 ax.axhline(0,color='#AAB2BC',lw=.8)
 ax.scatter([0],[0],s=10,color='black',zorder=7)
 ax.set_xlim(-1.08,1.08); ax.set_ylim(-1.08,1.08)
 ax.set_aspect('equal');ax.set_xticks([]);ax.set_yticks([])
 for spine in ax.spines.values():spine.set_visible(False)

# Figure 1: 3 Smith charts at B8 upper passband endpoint
fig, axs=plt.subplots(1,3,figsize=(15.5,5.6),constrained_layout=False)
summary=[];points=[]
for ax,(d,label) in zip(axs,DESIGNS.items()):
 chart_grid(ax,labels=True)
 o=calc(d,'B8',960);g=o['g']
 ax.plot(g.real,g.imag,lw=2.3,color='#243044',zorder=3)
 for j in range(4):
  z1,z2=g[j],g[j+1]
  ax.annotate('',xy=(z2.real,z2.imag),xytext=(z1.real,z1.imag),arrowprops=dict(arrowstyle='->',color='#243044',lw=1.5,mutation_scale=12),zorder=4)
 for i,(z,c) in enumerate(zip(g,STAGE_COLORS)):
  ax.scatter(z.real,z.imag,s=68,color=c,edgecolors='white',linewidths=1.5,zorder=5)
  dx,dy=[(.045,-.075),(.035,.045),(-.10,-.08),(-.08,.06),(.025,.105)][i]
  ax.text(z.real+dx,z.imag+dy,str(i),fontsize=9,weight='bold',color=c,zorder=8,ha='center',va='center',bbox=dict(boxstyle='round,pad=.13',facecolor='white',edgecolor='none',alpha=.9))
 ax.set_title(f'{label}   IL {o["IL"]:.4f} dB\n経路長 Σ|ΔΓ| = {o["len"]:.3f}',fontsize=12,weight='bold')
 for i in range(5):points.append({'design':d,'band':'B8','freq_MHz':960,'step':i,'step_name':STAGE[i],'Z_real_ohm':o['Z'][i].real,'Z_imag_ohm':o['Z'][i].imag,'gamma_real':o['g'][i].real,'gamma_imag':o['g'][i].imag})
 summary.append({'design':d,'band':'B8','freq_MHz':960,'maxIL_or_IL_dB':o['IL'],'smith_chord_sum':o['len'],'reflection_power_pct':o['reflP']*100,'L1_loss_mW':o['Lloss'][0]*1000,'L2_loss_mW':o['Lloss'][1]*1000,'L3_loss_mW':o['Lloss'][2]*1000,'L4_loss_mW':o['Lloss'][3]*1000,'C_loss_mW':sum(o['Closs'])*1000})
fig.suptitle('B8・960 MHz：負荷から入力への各ブロック動作インピーダンス（50Ω正規化）',y=.985,fontsize=15,weight='bold')
legend=[Line2D([0],[0],marker='o',color='w',markerfacecolor=c,markersize=8,label=f'{i}  {nm}') for i,(c,nm) in enumerate(zip(STAGE_COLORS,STAGE))]
fig.legend(handles=legend,loc='lower center',ncol=3,frameon=False,bbox_to_anchor=(.5,-.01),fontsize=10)
fig.subplots_adjust(top=.84,bottom=.21,left=.025,right=.975,wspace=.14)
fig.savefig(OUT/'smith_B8_960_three_designs.png',dpi=190,facecolor='white')
plt.close(fig)

# Figure 2: Frequency trajectories (B8 UL+DL) each cut for design B, and opposite frequency harmonic signal spot
fig,axs=plt.subplots(1,3,figsize=(15.3,5.6))
fs=np.r_[np.linspace(880,915,80),np.linspace(925,960,80)]
for ax,(d,title) in zip(axs,DESIGNS.items()):
 chart_grid(ax,labels=True)
 gg=np.array([calc(d,'B8',ff)['g'] for ff in fs])
 for j,c in enumerate(STAGE_COLORS):
  ax.plot(gg[:,j].real,gg[:,j].imag,c=c,lw=2.1,zorder=3,alpha=.9)
  for fmark in (880,960):
   idx=np.argmin(abs(fs-fmark));z=gg[idx,j]
   ax.scatter(z.real,z.imag,c=c,marker='s' if fmark==880 else 'o',s=28,zorder=4,edgecolor='white',linewidth=.4)
 ax.set_title(f'{title}  ｜  B8：880–915 / 925–960 MHz',fontsize=11,weight='bold')
fig.suptitle('B8通過帯域における各切断面の周波数軌跡',fontsize=15,weight='bold',y=.97)
fig.legend(handles=legend,loc='lower center',ncol=3,frameon=False,bbox_to_anchor=(.5,.003),fontsize=9)
fig.text(.5,.12,'□ = 880 MHz、○ = 960 MHz。線は周波数を動かしたときの各切断面の動きであり、ブロック間の変換経路ではありません。',ha='center',fontsize=9,color='#59616C')
fig.subplots_adjust(top=.84,bottom=.27,left=.025,right=.98,wspace=.12)
fig.savefig(OUT/'smith_B8_passband_frequency_tracks.png',dpi=185,facecolor='white')
plt.close(fig)

# Figure 3: six-band high-frequency edge, path-length and losses
band_fs={'B71':698,'B12':746,'B28':803,'B13+14':798,'B26':894,'B8':960}
rows=[]
for d,title in DESIGNS.items():
 for band,ff in band_fs.items():
  o=calc(d,band,ff)
  rows.append({'design':title,'band':band,'freq_MHz':ff,'IL_dB':o['IL'],'Smith_path_chord_sum':o['len'],'Gamma_in_abs':abs(o['S11']),'L_loss_mW_per_1W':sum(o['Lloss'])*1000,'C_loss_mW_per_1W':sum(o['Closs'])*1000,'reflected_power_mW_per_1W':o['reflP']*1000})
summary_df=pd.DataFrame(rows);summary_df.to_csv(OUT/'smith_path_vs_losses_sixbands.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(points).to_csv(OUT/'smith_impedance_points_B8_960.csv',index=False,encoding='utf-8-sig')
fig,ax=plt.subplots(figsize=(8.5,5.6))
cs=['#2B9373','#C08035','#9B5BB3']
for (d,title),color in zip(DESIGNS.items(),cs):
 df=summary_df[summary_df.design==title]
 ax.scatter(df.Smith_path_chord_sum,df.IL_dB,s=62,color=color,label=title)
 for r in df.itertuples():
  if r.band in ['B71','B28','B8']:
   ax.annotate(r.band,(r.Smith_path_chord_sum,r.IL_dB),fontsize=8,xytext=(5,5),textcoords='offset points')
ax.set_xlabel('Smith座標の折れ線長  Σ|ΔΓ|  （5点・4区間）')
ax.set_ylabel('通過域端点の挿入損失  IL  [dB]')
ax.grid(alpha=.25)
ax.legend(title='設計',loc='upper left')
ax.set_title('Smith経路長と実損失：6ケースの通過帯域上端',fontsize=14)
fig.tight_layout();fig.savefig(OUT/'smith_length_vs_IL.png',dpi=190,facecolor='white');plt.close(fig)

# Figure 4: harmonic transformations in B8 balanced as an illustration
fig,axs=plt.subplots(1,2,figsize=(11.6,5.6))
for ax,ff in zip(axs,(1800,2700)):
 chart_grid(ax,labels=True)
 o=calc('balanced_33','B8',ff)
 g=o['g']
 ax.plot(g.real,g.imag,c='#243044',lw=1.9)
 for i,z in enumerate(g):
  ax.scatter(z.real,z.imag,s=57,color=STAGE_COLORS[i],edgecolor='white',lw=1,zorder=7)
  ax.text(z.real+.045,z.imag+.05,str(i),weight='bold',fontsize=9,color=STAGE_COLORS[i])
 ax.set_title(f'B案・{ff} MHz   減衰 {o["IL"]:.1f} dB\n|Γ入力|={abs(o["S11"]):.3f}',fontsize=12)
fig.suptitle('高調波ではインピーダンス整合を崩して通過電力を減らす',fontsize=14,weight='bold',y=.98)
fig.legend(handles=legend,loc='lower center',ncol=3,frameon=False,bbox_to_anchor=(.5,-.01),fontsize=10)
fig.subplots_adjust(top=.84,bottom=.20,left=.035,right=.975,wspace=.10)
fig.savefig(OUT/'smith_B8_harmonics_B.png',dpi=190,facecolor='white');plt.close(fig)

# Text report
with open(OUT/'smith_summary.txt','w',encoding='utf-8') as f:
 f.write('B8/960MHz loaded operating-impedance Smith path\n')
 for d,lab in DESIGNS.items():
  r=calc(d,'B8',960)
  f.write(f'{lab}: IL={r["IL"]:.6f} dB, chord-path={r["len"]:.6f}, |Gin|={abs(r["S11"]):.6f}\n')
  for sn,z in zip(STAGE,r['Z']):f.write(f'   {sn}  {z.real:.3f}{z.imag:+.3f}j ohm\n')
 f.write('NOTE: impedance V/I cuts with all mutual couplings active; NOT isolated cascade transformations.\n')
print(summary_df.to_string(index=False))
print('Files created:',*[str(p) for p in OUT.iterdir()],sep='\n')
