import numpy as np,json,time,sys
from scipy.optimize import differential_evolution,minimize
from lpf_expand import SMALL,LARGE,DENSE,calc,metr,K,RS,ZD
ops=('t2','cpar','t3')
bound=[(.001,27),(.001,27),(.25,8),(.001,27),(.25,8),(.001,100)]
def penalty(x):
 c2=K/(x[1]*x[2]*x[2]);c3=K/(x[3]*x[4]*x[4]);return 100*max(0,c2-100)**2+100*max(0,c3-100)**2

def func(x,m):
 r=calc(x,ops,SMALL)
 return float(r[:37].max()+40*(max(0,m-r[37:52].min())**2+max(0,m-r[52:].min())**2)+penalty(x))
def refine(x,m):
 def cons(y):
  r=calc(y[:-1],ops,LARGE)
  c2=K/(y[1]*y[2]*y[2]); c3=K/(y[3]*y[4]*y[4])
  return np.r_[y[-1]-r[:181],r[181:252]-m,r[252:]-m,100-c2,100-c3]
 return minimize(lambda y:y[-1],np.r_[x,metr(x,ops)[0]+.05],bounds=bound+[(0,20)],constraints={'type':'ineq','fun':cons},method='SLSQP',options={'maxiter':300,'ftol':1e-10})
if __name__=='__main__':
 m=float(sys.argv[1]) if len(sys.argv)>1 else 30.05
 out=[]
 for seed in [3,7,19,23,43,91,100,201,301,999,2026,4004]:
  st=time.perf_counter()
  de=differential_evolution(func,bound,args=(m,),seed=seed,maxiter=470,popsize=14,polish=True,tol=.002,atol=.0005)
  z=refine(de.x,m)
  x=z.x[:-1] if z.success and min(metr(z.x[:-1],ops)[2:])>=m-1e-4 and penalty(z.x[:-1])<1e-5 else de.x
  mm=metr(x,ops,DENSE)
  print('WIDE',m,seed,'objective',round(de.fun,5),'IL',round(mm[0],6),'stop',np.round(mm[2:],5),'f2f3',round(x[2],4),round(x[4],4),'physical',np.round([x[0],x[1],K/(x[1]*x[2]**2),x[3],K/(x[3]*x[4]**2),x[5]],5),'success',z.success,'elapsed',round(time.perf_counter()-st,1),flush=True)
  out.append({'seed':seed,'x':x.tolist(),'metrics':mm,'elapsed':time.perf_counter()-st})
  with open('/mnt/data/pwide_'+str(m)+'.json','w') as fw:json.dump(out,fw,indent=2)
