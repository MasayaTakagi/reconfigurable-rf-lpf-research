"""Six-state LTE LPF exploration: low-order lossy coupled-inductor model.
Units: L=nH, C=pF, f=MHz; transducer loss to 60-j40 ohm load.
Circuit D+: input shunt (L2 series C2), core (L1 parallel C1), output shunt (L3 series C3).
Mutual couplings: k12 k13 k23; positive and negative winding polarities.
Band 13+14 is one switching state; unions approximated without the small gaps.
Model only small-signal constant Q, not power, parasitics or realizable layout.
"""
import numpy as np
from scipy.optimize import differential_evolution, minimize
from numba import njit
from pathlib import Path
import csv, json, time, sys

Rs=50.0; ZD=60-40j
BANDS={
 'B71': {'ul':[(663,698)], 'dl':[(617,652)]},
 'B12': {'ul':[(699,716)], 'dl':[(729,746)]},
 'B28': {'ul':[(703,748)], 'dl':[(758,803)]},
 'B13+14':{'ul':[(777,787),(788,798)],'dl':[(746,756),(758,768)]},
 'B26': {'ul':[(814,849)], 'dl':[(859,894)]},
 'B8': {'ul':[(880,915)], 'dl':[(925,960)]}
}
# frequency sample blocks, with explicit UL/DL and harmonic spans for B13/14, optional include 1 MHz band gap.
def freqs(name, dense=False):
 b=BANDS[name]; n=18 if dense else 8
 pp=[];s2=[];s3=[]
 for key in ['ul','dl']:
  for lo,hi in b[key]:pp.extend(np.linspace(lo,hi,n))
 for lo,hi in b['ul']:
  s2.extend(np.linspace(lo*2,hi*2,n));s3.extend(np.linspace(lo*3,hi*3,n))
 return np.array(pp),np.array(s2),np.array(s3)

@njit(cache=True)
def il_three(x, ff, coupled=True, flipped=False, core_cap=True):
 """x = [L1,L2,L3,C1,C2,C3,k12,k13,k23]; outputs IL in dB."""
 L1,L2,L3,C1,C2,C3,k12,k13,k23=x
 result=np.empty(len(ff))
 if not coupled:k12=0.;k13=0.;k23=0.
 if flipped:
  L2,L3=L3,L2; C2,C3=C3,C2
  # swapping physical 2,3 also swaps couplings for orientation-insensitive named structure
  k12,k13=k13,k12
 for i in range(len(ff)):
  w=2*np.pi*ff[i]*1e6
  z1=(.04+1j)*w*L1*1e-9
  z2=(.04+1j)*w*L2*1e-9+(.0125-1j)/(w*C2*1e-12)
  z3=(.04+1j)*w*L3*1e-9+(.0125-1j)/(w*C3*1e-12)
  z12=1j*w*k12*np.sqrt(L1*L2)*1e-9
  z13=1j*w*k13*np.sqrt(L1*L3)*1e-9
  z23=1j*w*k23*np.sqrt(L2*L3)*1e-9
  det=z1*z2*z3+2*z12*z13*z23-z1*z23*z23-z2*z13*z13-z3*z12*z12
  g11=(z2*z3-z23*z23)/det
  g22=(z1*z3-z13*z13)/det
  g33=(z1*z2-z12*z12)/det
  g12=(z13*z23-z12*z3)/det
  g13=(z12*z23-z13*z2)/det
  g23=(z12*z13-z1*z23)/det
  y11=g11+g22+2*g12
  y22=g11+g33-2*g13
  y12=-g11+g13-g12+g23
  if core_cap:
   yc=w*C1*1e-12/(.0125-1j)
   y11+=yc;y22+=yc;y12-=yc
  ya=y11+1/Rs
  yd=y22+1/(60-40j)
  vout=-(y12/Rs)/(ya*yd-y12*y12)
  eta=4*Rs*(60/5200)*abs(vout)**2
  result[i]=-10*np.log10(max(eta,1e-160))
 return result

@njit(cache=True)
def il_four(x,ff,extra_out=True):
 """4L 4C: D+ plus fourth shunt series-LC trap at output/input, no mutual to added coil.
 x=[L1..L4,C1..C4,k12,k13,k23]; 4th L is uncoupled by construction.
 """
 L1,L2,L3,L4,C1,C2,C3,C4,k12,k13,k23=x
 result=np.empty(len(ff))
 for i in range(len(ff)):
  w=2*np.pi*ff[i]*1e6
  z1=(.04+1j)*w*L1*1e-9
  z2=(.04+1j)*w*L2*1e-9+(.0125-1j)/(w*C2*1e-12)
  z3=(.04+1j)*w*L3*1e-9+(.0125-1j)/(w*C3*1e-12)
  z4=(.04+1j)*w*L4*1e-9+(.0125-1j)/(w*C4*1e-12)
  z12=1j*w*k12*np.sqrt(L1*L2)*1e-9
  z13=1j*w*k13*np.sqrt(L1*L3)*1e-9
  z23=1j*w*k23*np.sqrt(L2*L3)*1e-9
  det=z1*z2*z3+2*z12*z13*z23-z1*z23*z23-z2*z13*z13-z3*z12*z12
  g11=(z2*z3-z23*z23)/det
  g22=(z1*z3-z13*z13)/det
  g33=(z1*z2-z12*z12)/det
  g12=(z13*z23-z12*z3)/det
  g13=(z12*z23-z13*z2)/det
  g23=(z12*z13-z1*z23)/det
  yc=w*C1*1e-12/(.0125-1j)
  y11=g11+g22+2*g12+yc
  y22=g11+g33-2*g13+yc
  y12=-g11+g13-g12+g23-yc
  if extra_out:y22+=1/z4
  else:y11+=1/z4
  vout=-(y12/Rs)/((y11+1/Rs)*(y22+1/(60-40j))-y12*y12)
  eta=4*Rs*(60/5200)*abs(vout)**2
  result[i]=-10*np.log10(max(eta,1e-160))
 return result

def psd(k):
 a,b,c=k
 return 1+2*a*b*c-a*a-b*b-c*c

BASE_DPLUS=np.array([7.73065982,8.61767119,5.67966979,.68848820,.92797716,.60466583,0,0,0])
BS3=[(1.,27.)]*3+[(.15,15.)]*3+[(-.45,.45)]*3
BS4=[(1.,27.)]*4+[(.15,15.)]*4+[(-.45,.45)]*3

def per_band_metrics(x,band, coupled=True, topology='D+', dense=True):
 fp,f2,f3=freqs(band,dense)
 if topology=='D+' or topology=='D':
  fn=lambda arr:il_three(x,arr,coupled=coupled,core_cap=topology=='D+')
 elif topology=='D+_reverse':fn=lambda arr:il_three(x,arr,coupled=coupled,flipped=True)
 elif topology=='4L4C_OUT':fn=lambda arr:il_four(x,arr,extra_out=True)
 elif topology=='4L4C_IN':fn=lambda arr:il_four(x,arr,extra_out=False)
 a,b,c=fn(fp),fn(f2),fn(f3)
 return dict(max_IL=float(max(a)),mean_IL=float(np.mean(a)),stop2=float(min(b)),stop3=float(min(c)),minPSD=float(psd(x[-3:])))

def band_score(x,band, coupled=True, topology='D+',atten=30.,dense=False):
 if psd(x[-3:]) < .005:return 500+1000*abs(psd(x[-3:]))
 fp,f2,f3=freqs(band,dense)
 if topology in ('D+','D'):
  fn=lambda f:il_three(x,f,coupled,False,topology=='D+')
 elif topology=='D+_reverse':fn=lambda f:il_three(x,f,coupled,True,True)
 elif topology=='4L4C_OUT':fn=lambda f:il_four(x,f,True)
 else:fn=lambda f:il_four(x,f,False)
 a,b,c=fn(fp),fn(f2),fn(f3)
 penalty=30*(max(0,atten-min(b))**2+max(0,atten-min(c))**2)
 return float(max(a)+penalty)

def opt_single(band,coupled=True,topology='D+',iters=145,pop=9,seed=1):
 bounds=BS4 if topology.startswith('4L') else BS3
 if not coupled:bounds=bounds[:-3]+[(0.,0.)]*3
 start=time.monotonic()
 de=differential_evolution(lambda x:band_score(x,band,coupled,topology),bounds,popsize=pop,maxiter=iters,seed=seed,tol=.003,polish=True,workers=1)
 xx=de.x
 # constrained sample-based sequential polishing with epigraph
 fp,f2,f3=freqs(band,True)
 def vals(y):
  if topology=='D+':fn=lambda f:il_three(y[:-1],f,coupled)
  elif topology=='D':fn=lambda f:il_three(y[:-1],f,coupled,False,False)
  elif topology=='D+_reverse':fn=lambda f:il_three(y[:-1],f,coupled,True)
  elif topology=='4L4C_OUT':fn=lambda f:il_four(y[:-1],f,True)
  else:fn=lambda f:il_four(y[:-1],f,False)
  return fn(fp),fn(f2),fn(f3)
 def con(y):
  a,b,c=vals(y)
  return np.r_[y[-1]-a,b-30,c-30,psd(y[-4:-1])-.005]
 # local approximate feasible
 init=np.r_[xx,per_band_metrics(xx,band,coupled,topology)['max_IL']+.2]
 res=minimize(lambda y:y[-1],init,method='SLSQP',bounds=bounds+[(0,15)],constraints={'type':'ineq','fun':con},options={'maxiter':120,'ftol':1e-8})
 xx2=res.x[:-1]
 sc1=band_score(xx,band,coupled,topology,30,True)
 sc2=band_score(xx2,band,coupled,topology,30,True)
 if sc2<sc1:xx=xx2
 return xx,per_band_metrics(xx,band,coupled,topology,True),round(time.monotonic()-start,1)

if __name__=='__main__':
 a=sys.argv[1] if len(sys.argv)>1 else 'test'
 if a=='test':
  for b in ['B8','B71']:
   print(b,per_band_metrics(BASE_DPLUS,b),flush=True)
