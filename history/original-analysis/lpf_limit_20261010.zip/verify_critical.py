import sys,json,numpy as np,csv
from scipy.optimize import minimize_scalar
sys.path.insert(0,'/mnt/data/lpf_next')
from explore import *
a=json.load(open('/mnt/data/lpf_limit_study/limits.json'));b=json.load(open('/mnt/data/lpf_limit_study/target33.json'))
sets=[('k025_35dB',next(d for d in a if d['target']==35.05 and d['kmax']==.25)),('k050_35dB',next(d for d in a if d['target']==35.05 and d['kmax']==.5)),('k025_33dB',next(d for d in b if d['kmax']==.25)),('k050_33dB',next(d for d in b if d['kmax']==.5))]
Q=np.array([25.,25.,25.,25.,80.]);T=three_series(2)
def extremal(z,low,hi,maximize):
 ff=np.linspace(low,hi,max(2,int(np.ceil((hi-low)/.02))+1));v=transfer(z,ff,*T,Q)
 loc=np.r_[0, len(ff)-1,np.where(((v[1:-1]>=v[:-2])&(v[1:-1]>=v[2:])) if maximize else ((v[1:-1]<=v[:-2])&(v[1:-1]<=v[2:])))[0]+1]; cand=[]
 for pos in loc:
  if pos==0 or pos==len(ff)-1:cand.append((float(v[pos]),float(ff[pos])));continue
  aa,bb=ff[pos-1],ff[pos+1]
  fun=lambda f:float(transfer(z,np.array([f]),*T,Q)[0])
  sol=minimize_scalar((lambda f:-fun(f)) if maximize else fun,bounds=(aa,bb),method='bounded',options={'xatol':1e-6})
  cand.append((fun(sol.x),sol.x))
 return (max(cand,key=lambda d:d[0]) if maximize else min(cand,key=lambda d:d[0]))
rows=[]
for name,d in sets:
 x=np.array(d['x']); mx=-1;h2=1e5;h3=1e5;critical={}
 for bandidx,band in enumerate(NAMES):
  zz=np.r_[x[:4],x[10+4*bandidx:14+4*bandidx],x[4:10]]
  p=[extremal(zz,lo,hi,True) for lo,hi in BANDS[band]['ul']+BANDS[band]['dl']]
  q2=[extremal(zz,lo*2,hi*2,False) for lo,hi in BANDS[band]['ul']]
  q3=[extremal(zz,lo*3,hi*3,False) for lo,hi in BANDS[band]['ul']]
  il=max(p,key=lambda v:v[0]);a2=min(q2,key=lambda v:v[0]);a3=min(q3,key=lambda v:v[0]);mx=max(mx,il[0]);h2=min(h2,a2[0]);h3=min(h3,a3[0]);
  row=dict(design=name,band=band,IL=il[0],freq_IL=il[1],H2=a2[0],freq_H2=a2[1],H3=a3[0],freq_H3=a3[1]);rows.append(row)
  print(name,band,'IL',round(il[0],6),'2f',round(a2[0],6),'3f',round(a3[0],6),flush=True)
 print('SUMMARY',name,'IL',mx,'H2',h2,'H3',h3,flush=True)
with open('/mnt/data/lpf_limit_study/dense_frequency_verification.csv','w',newline='') as fp:
 w=csv.DictWriter(fp,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
