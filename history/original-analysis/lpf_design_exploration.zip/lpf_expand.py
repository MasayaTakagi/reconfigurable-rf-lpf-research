import numpy as np
from scipy.optimize import differential_evolution, minimize
from functools import partial
import json,sys,time
RS=50.; ZD=60-40j; K=1000/(4*np.pi**2)
SMALL=np.r_[np.linspace(600,960,37),np.linspace(1760,1830,15),np.linspace(2640,2745,22)]*1e6
LARGE=np.r_[np.linspace(600,960,181),np.linspace(1760,1830,71),np.linspace(2640,2745,106)]*1e6
DENSE=np.r_[np.linspace(600,960,1801),np.linspace(1760,1830,701),np.linspace(2640,2745,1051)]*1e6

# configs: 3L+3C. variable vector [Lcore,Ltrap2, f2,G=Ltrap3,f3,Cextra], G controls trap3's L.
# Baseline D: T2 (shunt series LC) -> core L -> T3 (shunt series LC), optional sixth capacitor
# ops: t2, t3, l, cs (series C), cp (shunt C), cpar (C in parallel with L core), cb (cap across both ports)
# mixed class later

def calc(x,ops,f=SMALL):
  ls,l2,f2,l3,f3,cx=np.array(x,float)
  w=2*np.pi*f
  zL=lambda n:(w*n*1e-9)*(1/25.+1j)
  zC=lambda p: (1/80.-1j)/(w*p*1e-12)
  zl,z2,z3,zc=zL(ls),zL(l2)+zC(K/(l2*f2*f2)),zL(l3)+zC(K/(l3*f3*f3)),zC(cx)
  a=np.ones_like(w,dtype=complex); b=np.zeros_like(w,dtype=complex); c=np.zeros_like(w,dtype=complex); d=np.ones_like(w,dtype=complex)
  for op in ops:
    if op=='t2': y=1/z2
    elif op=='t3': y=1/z3
    elif op=='cp': y=1/zc
    elif op in ('l','cpar','cs','cb'): y=None
    else: raise ValueError(op)
    if y is None:
      if op=='l': zz=zl
      elif op=='cpar': zz=zl*zc/(zl+zc)
      elif op=='cs': zz=zc
      elif op=='cb': raise ValueError('bridge not supported')
      b=a*zz+b; d=c*zz+d
    else:
      a=a+b*y; c=c+d*y
  denominator=a*ZD+b+RS*(c*ZD+d)
  eta=4*RS*ZD.real/np.abs(denominator)**2
  return -10*np.log10(np.clip(eta,1e-100,1))
B=[(.001,27),(.15,27),(1.65,2.05),(.15,27),(2.45,3.05),(.01,100)]
def metr(x,ops,f=LARGE):
  r=calc(x,ops,f); i=np.count_nonzero((f>=600e6)&(f<=960e6)); j=np.count_nonzero((f>=1760e6)&(f<=1830e6));return [float(r[:i].max()),float(r[:i].mean()),float(r[i:i+j].min()),float(r[i+j:].min())]
def obj(x,ops,target=30.05,f=SMALL):
  try: r=calc(x,ops,f)
  except: return 1e4
  n=np.count_nonzero(f<=960e6);m=np.count_nonzero((f>=1760e6)&(f<=1830e6))
  return float(r[:n].max()+45*(max(0,target-r[n:n+m].min())**2+max(0,target-r[n+m:].min())**2))
def sls(x,ops,target=30.05):
  f=LARGE; n=181; m=71
  def con(y):
    r=calc(y[:-1],ops,f)
    return np.r_[y[-1]-r[:n],r[n:n+m]-target,r[n+m:]-target]
  rr=calc(x,ops,f)
  return minimize(lambda y:y[-1], np.r_[x,max(rr[:n])+.05],method='SLSQP',bounds=B+[(0,25)],constraints={'type':'ineq','fun':con},options={'maxiter':220,'ftol':1e-10})

def run_one(ops,target,seeds=[12,28],iters=270,pop=12):
  ans=[]
  for seed in seeds:
    de=differential_evolution(obj,B,args=(ops,target),seed=seed,maxiter=iters,popsize=pop,polish=True,tol=.002,atol=.0001)
    sl=sls(de.x,ops,target)
    st=metr(sl.x[:-1],ops)
    cand=(st[0],sl.x[:-1],st, bool(sl.success))
    if min(st[2:])>=target-1e-4: ans.append(cand)
    else:
      st=metr(de.x,ops)
      if min(st[2:])>=target-1e-4: ans.append((st[0],de.x,st,False))
  return min(ans,key=lambda z:z[0]) if ans else None

if __name__=='__main__':
  typ=sys.argv[1] if len(sys.argv)>1 else 'd'; target=float(sys.argv[2]) if len(sys.argv)>2 else 30.05
  out=[]
  cases=[]
  for rev in [False,True]:
    A='t3' if rev else 't2';Z='t2' if rev else 't3'
    cases += [(('D_'+('rev' if rev else 'fwd')), (A,'l',Z),False)]
    cases += [(('P_'+('rev' if rev else 'fwd')), (A,'cpar',Z),True)]
    cases += [(('SC_'+('rev' if rev else 'fwd')), (A,'l','cs',Z),True)]
    cases += [(('SCIN_'+('rev' if rev else 'fwd')), ('cs',A,'l',Z),True)]
    cases += [(('SCOUT_'+('rev' if rev else 'fwd')), (A,'l',Z,'cs'),True)]
    cases += [(('CPIN_'+('rev' if rev else 'fwd')), ('cp',A,'l',Z),True)]
    cases += [(('CPOUT_'+('rev' if rev else 'fwd')), (A,'l',Z,'cp'),True)]
  if typ=='d': cases=[c for c in cases if c[0].startswith(('D','P','SC'))]
  if typ=='c': cases=[c for c in cases if c[0].startswith(('CP',))]
  if typ=='all':pass
  for k,ops,extra in cases:
    st=time.perf_counter()
    result=run_one(ops,target,seeds=[23,76] if typ!='all' else [76],iters=250 if typ!='all' else 200,pop=12)
    if result:
      score,values,metrics,success=result
      print(k,'T',target,'best',round(score,5),'stops',round(metrics[2],4),round(metrics[3],4),'x',np.round(values,6),'C2',round(K/(values[1]*values[2]**2),6),'C3',round(K/(values[3]*values[4]**2),6),'success',success,'time',round(time.perf_counter()-st,1),flush=True)
      out.append(dict(name=k,ops=ops,score=score,x=values.tolist(),metrics=metrics,success=success))
    else: print(k,'NO FEAS',round(time.perf_counter()-st,1),flush=True)
    with open('/mnt/data/expanded_'+typ+'_'+str(target)+'.json','w') as fh:json.dump(out,fh,indent=2)
