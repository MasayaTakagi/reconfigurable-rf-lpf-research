import numpy as np,json,time
from scipy.optimize import minimize
from run_4L import *
phys=json.load(open('/mnt/data/lpf_sixband/physical_screen.json'))
base=next(r for r in phys if r['feasible'] and r['minC']==.5 and r['start']=='best')
bounds=[(1,27)]*4+[(-.25,.25)]*3+sum([[(.5,6)]*4 for i in range(6)],[])
allr=[]
for target in [31,33,35]:
 def funcons(y):
  ff=cons(y,False)
  # earlier last 1 is psd; shift all other constraints for harmonic entries only
  g=[]
  for i,b in enumerate(NAMES):
   f,f2,f3=LARGE[i]
   x=to_x4(y[:-1],i)
   g.extend(y[-1]-il_four(x,f,False))
   g.extend(il_four(x,f2,False)-target)
   g.extend(il_four(x,f3,False)-target)
  g.append(psd(y[4:7])-.005)
  return np.array(g)
 x=np.array(base['params']) if len(allr)==0 else np.array(allr[-1]['params'])
 init=np.r_[x,getval(x,False)['max_IL']+.35]
 t=time.time()
 res=minimize(lambda y:y[-1],init,method='SLSQP',bounds=bounds+[(0,10)],constraints={'type':'ineq','fun':funcons},options={'maxiter':250,'ftol':1e-9})
 v=getval(res.x[:-1],False)
 rec=dict(target=target,params=res.x[:-1].tolist(),metrics=v,mincon=float(min(funcons(res.x))),success=bool(res.success),niter=int(res.nit))
 print(target,'IL',v['max_IL'],'stop',v['worststop'],'feasibility',rec['mincon'],'niter',res.nit,'time',round(time.time()-t,1),flush=True)
 allr.append(rec)
 open('/mnt/data/lpf_sixband/margins.json','w').write(json.dumps(allr,indent=2))
