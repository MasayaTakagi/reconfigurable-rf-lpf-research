import sys,json,numpy as np,time
sys.path.insert(0,'/mnt/data/lpf_newwork')
from alt_topology import opt,IL_3node,xpar,ev
from opt_compare import metrics,base4
from lpf_sixband import BANDS
old=json.load(open('/mnt/data/lpf_newwork/alt_results_fixed.json'))
results=[]
for idx,q1,q4 in [(0,25,25),(1,30,25),(3,30,30)]:
 seed=np.array(old[idx]['x'])
 r=opt(seed,0,ql1=q1,ql4=q4,atten=35.05,maxiter=110)
 results.append(r)
 json.dump(results,open('/mnt/data/lpf_newwork/refined_results.json','w'),indent=2)
 # dense validation approx 0.1 MHz
 for i,band in enumerate(BANDS):
  x=xpar(np.array(r['x']),i)
  blocks=[]
  for spec in ['pass','h2','h3']:
   ranges=[]
   if spec=='pass':
    ranges=BANDS[band]['ul']+BANDS[band]['dl']; mul=1
   elif spec=='h2':ranges=BANDS[band]['ul'];mul=2
   else:ranges=BANDS[band]['ul'];mul=3
   freq=np.concatenate([np.linspace(a*mul,b*mul,1+int((b-a)*mul/.1)) for a,b in ranges])
   v=IL_3node(x,freq,0,q1,q4)
   blocks.append((float(np.max(v)) if spec=='pass' else float(np.min(v)),float(freq[np.argmax(v) if spec=='pass' else np.argmin(v)])))
  print('DENSE',q1,q4,band,'pass',tuple(round(t,5) for t in blocks[0]),'h2',tuple(round(t,5) for t in blocks[1]),'h3',tuple(round(t,5) for t in blocks[2]),flush=True)
