import sys,os,json
import numpy as np
sys.path[:0]=['/mnt/data/lpf_pcb_expansion'];from bridge_exp import optimize
out=[];f='/mnt/data/lpf_pcb_expansion/cap_results.json'
patterns=[[(0,2),(1,-1)],[(1,-1),(2,-1)],[(0,2),(1,3)],[(1,-1),(0,3)],[(0,3),(2,-1)],[(1,3),(2,-1)],[(0,2),(1,3),(2,-1)],[(1,-1),(2,-1),(0,3)],[(0,2),(1,3),(1,-1)],[(0,2),(2,-1),(1,-1)],[(0,2),(1,3),(1,-1),(2,-1)],[(1,-1),(2,-1),(0,-1)]]
for j,ed in enumerate(patterns):
 r=optimize([],ed,maxiter=280)
 out.append(r);json.dump(out,open(f,'w'),indent=1)
 print('CAP',j+1,ed,'IL',round(r['IL'],6),'H2',round(r['H2'],3),'H3',round(r['H3'],3),'ok',r['good'],'t',r['time'],flush=True)
for r in sorted([r for r in out if r['good']],key=lambda d:d['IL'])[:3]:
 rr=optimize([],r['cap_edges'],np.array(r['x']),maxiter=300)
 out.append(rr);json.dump(out,open(f,'w'),indent=1)
 print('REFINE',rr['cap_edges'],'IL',round(rr['IL'],6),'H2',round(rr['H2'],3),'H3',round(rr['H3'],3),'ok',rr['good'],flush=True)
