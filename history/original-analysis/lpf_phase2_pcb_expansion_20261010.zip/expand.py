import sys,os,json,time,itertools
import numpy as np
from numba import njit
from scipy.optimize import minimize
sys.path[:0]=['/mnt/data/lpf_next']
from explore import three_series,MED,SMALL,DENSE,NAMES,COUPLES,psd

ROOT='/mnt/data/lpf_pcb_expansion'; BASE=json.load(open('/mnt/data/lpf_phase2_extension/first.json'))
B,SER,CE=three_series(2)
@njit(cache=True)
def transfer_exp(L,ks,pcbl,caps,fs,pcb_nodes,cap_edges):
  npcb=len(pcbl); nnode=B.shape[1]; out=np.empty(len(fs),np.float64)
  for idx in range(len(fs)):
    w=2*np.pi*fs[idx]*1e6
    Z=np.zeros((4,4),np.complex128)
    for j in range(4):
      Z[j,j]=w*L[j]*1e-9*(1j+1/25.)
      if SER[j]:Z[j,j]+=(1./80.-1j)/(w*caps[j]*1e-12)
    for j in range(6):
      a=COUPLES[j,0];b=COUPLES[j,1]
      Z[a,b]=Z[b,a]=1j*w*ks[j]*np.sqrt(L[a]*L[b])*1e-9
    Y=B.T@np.linalg.solve(Z,B)
    for j in range(len(CE)):
      ci=int(CE[j,0]);a=int(CE[j,1]);b=int(CE[j,2]);y=w*caps[ci]*1e-12/(1/80.-1j)
      if a>=0:Y[a,a]+=y
      if b>=0:Y[b,b]+=y
      if a>=0 and b>=0:Y[a,b]-=y;Y[b,a]-=y
    for j in range(npcb):
      Zp=w*pcbl[j]*1e-9*(1j+1/12.)+(1/80.-1j)/(w*caps[4+j]*1e-12)
      node=pcb_nodes[j];Y[node,node]+=1/Zp
    for j in range(len(cap_edges)):
      a=cap_edges[j,0];b=cap_edges[j,1];y=w*caps[4+npcb+j]*1e-12/(1/80.-1j)
      if a>=0:Y[a,a]+=y
      if b>=0:Y[b,b]+=y
      if a>=0 and b>=0:Y[a,b]-=y;Y[b,a]-=y
    Y[0,0]+=1/50.
    Y[nnode-1,nnode-1]+=1/(60.-40j)
    rhs=np.zeros(nnode,np.complex128);rhs[0]=1/50.
    v=np.linalg.solve(Y,rhs)
    eta=4*50*(60/5200)*abs(v[nnode-1])**2
    out[idx]=-10*np.log10(max(eta,1e-99))
  return out

def initial(pcb_nodes,cap_edges,pcbLinit=2.,cinit=1.5,ceinit=.15,seed=None):
 x=np.array(BASE['x'] if seed is None else seed,dtype=float);nP=len(pcb_nodes);nC=len(cap_edges)
 if len(x)!=34: raise ValueError('expected base')
 return np.r_[x[:10],np.full(nP,pcbLinit),np.array([np.r_[x[10+4*b:14+4*b],np.full(nP,cinit),np.full(nC,ceinit)] for b in range(6)]).ravel()]

def optimize(pcb_nodes,cap_edges=(),seed=None,grid=SMALL,maxiter=160,target=35.05):
  pn=np.asarray(pcb_nodes,np.int64); ce=np.asarray(cap_edges,np.int64).reshape((-1,2));nP=len(pn);nC=len(ce);d=4+nP+nC
  bnd=[(.4,27.)]*4+[(-.25,.25) if i in (2,3) else (-.16,.16) for i in range(6)]+[(.1,3.)]*nP+[(.1,100.)]*(6*d)
  x=initial(pn,ce) if seed is None else seed.copy(); x=np.clip(x,np.array(bnd)[:,0],np.array(bnd)[:,1]);x0=np.r_[x,1.]
  def vec(x,b,f):return transfer_exp(x[:4],x[4:10],x[10:10+nP],x[10+nP+b*d:10+nP+(b+1)*d],f,pn,ce)
  def con(z):
    x=z[:-1];t=z[-1];out=[]
    for i,(fp,f2,f3) in enumerate(grid):
      out.extend(t-vec(x,i,fp))
      out.extend(vec(x,i,f2)-target)
      out.extend(vec(x,i,f3)-target)
    out.append(psd(x[4:10])-.01)
    return np.asarray(out)
  tic=time.perf_counter()
  r=minimize(lambda z:z[-1],x0,method='SLSQP',bounds=bnd+[(0,6)],constraints=[{'type':'ineq','fun':con}],options={'maxiter':maxiter,'ftol':3e-9})
  z=r.x; x=z[:-1]; vals=[]
  for i,(p,s,t) in enumerate(DENSE): vals.append((float(max(vec(x,i,p))),float(min(vec(x,i,s))),float(min(vec(x,i,t)))))
  il=max(v[0] for v in vals);h2=min(v[1] for v in vals);h3=min(v[2] for v in vals)
  feas=il<z[-1]+.02 and h2>=target-.015 and h3>=target-.015 and psd(x[4:10])>=.009
  return {'pcb_nodes':pn.tolist(),'cap_edges':ce.tolist(),'nP':nP,'nC':nC,'IL':il,'H2':h2,'H3':h3,'target':target,'feasible':bool(feas),'success':bool(r.success),'sec':round(time.perf_counter()-tic,2),'x':x.tolist(),'perband':dict(zip(NAMES,vals)),'iter':int(r.nit),'message':r.message}

def cont_seed(prev,new_pcb,new_ce,init_pcb=1.5,init_c=1.5,init_extra_c=.1):
  oldN=prev['nP'];oldC=prev['nC'];x=np.array(prev['x']); dprev=4+oldN+oldC; dnew=4+len(new_pcb)+len(new_ce)
  # append only; preserve existing pcb and C placement
  xnew=np.r_[x[:10],x[10:10+oldN],np.full(len(new_pcb)-oldN,init_pcb),np.array([np.r_[x[10+oldN+b*dprev:10+oldN+b*dprev+4],x[10+oldN+b*dprev+4:10+oldN+b*dprev+4+oldN],np.full(len(new_pcb)-oldN,init_c), x[10+oldN+b*dprev+4+oldN:10+oldN+(b+1)*dprev],np.full(len(new_ce)-oldC,init_extra_c)] for b in range(6)]).ravel()]
  return xnew

def main():
  hist=[]
  def run(pn,ce=(),seed=None,maxiter=135,grid=SMALL):
    res=optimize(pn,ce,seed,maxiter=maxiter,grid=grid)
    hist.append(res); json.dump(hist,open(ROOT+'/results.json','w'),indent=1)
    print('RUN',len(hist),'PCB',pn,'extra C',ce,'IL',round(res['IL'],7),'H2',round(res['H2'],3),'H3',round(res['H3'],3),'ok',res['feasible'],'sec',res['sec'],'Lpcb',np.round(res['x'][10:10+len(pn)],3),flush=True)
    return res
  # warm numba
  tmp=initial([1],());transfer_exp(tmp[:4],tmp[4:10],tmp[10:11],tmp[11:16],SMALL[0][0],np.array([1],np.int64),np.empty((0,2),np.int64))
  # 2 pcb shunts
  two=[]
  for nodes in [(0,1),(0,2),(0,3),(1,2),(1,3),(2,3),(1,1),(2,2)]:
    two.append(run(nodes,maxiter=130))
  # add third shunt to top candidates
  best=sorted([r for r in two if r['feasible']],key=lambda r:r['IL'])[:3]
  three=[]
  for b in best:
    for node in [0,1,2,3]:
      pn=b['pcb_nodes']+[node]
      if any(tuple(r['pcb_nodes'])==tuple(pn) and len(r['cap_edges'])==0 for r in three):continue
      seed=cont_seed(b,pn,[])
      three.append(run(pn,seed=seed,maxiter=160))
  # bridge/shunt capacitors plus 2 shunt PCB
  b=best[0]
  mixed=[]
  for ce in [[(0,3)],[(0,2)],[(1,3)],[(1,-1)],[(2,-1)],[(1,3),(1,-1)],[(0,2),(2,-1)]]:
    mixed.append(run(b['pcb_nodes'],ce,cont_seed(b,b['pcb_nodes'],ce),maxiter=180))
  # best2/3 into medium grid polish
  results=sorted([r for r in hist if r['feasible']],key=lambda z:z['IL'])
  if results:
    for b in results[:3]:
      run(b['pcb_nodes'],b['cap_edges'],np.array(b['x']),maxiter=300,grid=MED)
  print('BEST',[(round(r['IL'],6),r['pcb_nodes'],r['cap_edges']) for r in sorted((r for r in hist if r['feasible']),key=lambda r:r['IL'])[:12]],flush=True)

if __name__=='__main__':main()
