LPF design exploration / 2026-10-09

SPECIFICATION
Passband: 600-960 MHz, minimize worst-case transducer insertion loss.
Stopbands: 1760-1830 and 2640-2745 MHz, each >=30 dB.
Generator resistance: 50 ohm. Complex load: 60-j40 ohm at all frequencies.
Up to 3 inductors <=27nH, up to 3 capacitors <=100pF.
Constant quality factors: Q_L=25, Q_C=80.
No parasitic capacitances or couplings included.

MAIN RESULT (LUMPED MODEL, NOT GLOBALLY PROVEN)
D+ topology: input shunt L2+C2 series resonance; series-path L1||C1;
output shunt L3+C3 series resonance.
Nominal 30.05 dB attenuation target:
  L1=7.73065982 nH   C1=0.68848820 pF
  L2=8.61767119 nH   C2=0.92797716 pF
  L3=5.67966979 nH   C3=0.60466583 pF
  worst passband IL 0.39677568 dB; both stopband minima 30.05dB.
35dB attenuation target:
  L1=8.32667961 nH   C1=0.62805454 pF
  L2=5.91715365 nH   C2=1.35067360 pF
  L3=4.03444565 nH   C3=0.85082846 pF
  worst passband IL 0.50392405 dB; both stopband minima 35dB.

MODEL
Z_L(f)=2*pi*f*L*(1/Q_L+j)
Z_C(f)=(1/Q_C-j)/(2*pi*f*C)
ABCD matrix eta=4*R_s*Re(Z_load)/|A*Z_load+B+R_s*(C*Z_load+D)|^2.
IL=-10 log10(eta).
Note parameter frequency f in GHz in tuned optimizer input arrays.

FILES
- lpf_expand.py: dual-shunt, added capacitor variants and optimizer; component x=[Lcore,Ltrap2,ftrap2,Ltrap3,ftrap3,Cextra].
- lpf_mixed.py: forward mixed trap + parallel resonance and optimizer.
- lpf_mixed_rev.py: reverse-frequency arrangement optimizer.
- lpf_pp.py: two series-parallel resonators and matching stage.
- lpf_pwide.py: wide resonance-frequency multistart for D+.
- expanded_*.json, mixed_*.json, pp_*.json, pwide_*.json: numerical search outputs.
- lpf_all_explored_candidates.csv: explored placement cases (some electrically equivalent).
- lpf_expanded_comparison.png: candidate spectral plots.
- lpf_topology_comparison.csv: summary of highlighted candidates.

LIMITS
Optimization was multistart differential evolution followed by constrained SLSQP.
Discrete sampled frequencies are used in optimizer (larger-grid and 0.01MHz checks for the highlighted D+ candidates).
Candidate circuit feasibility and global optimality across the full continuum are not formally certified.
The topology library is selective, not an exhaustive enumeration of all undirected L/C graph topologies, especially bridge networks.
The lower numerical bounds (.001 nH, .01 pF etc.) are solver approximations for zero, not original user constraints.
To certify global optimality, enumerate all nonisomorphic relevant graph topologies,
prove interval feasibility over full frequency intervals and component boxes,
and use validated global optimization to supply a lower bound matching the feasible upper bound.
